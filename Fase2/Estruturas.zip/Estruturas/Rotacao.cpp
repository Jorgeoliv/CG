#include "Rotacao.h"
#include <iostream>

using namespace std;


Rotacao::Rotacao() : Operacao() {
}


Rotacao::Rotacao(float x, float y, float z, float angulo)
      : Operacao(x, y, z), angulo(angulo) { }


float Rotacao::getAngulo(){
	return angulo;
}


float Rotacao::setAngulo(float a){
	angulo=a;
}


string Rotacao::toString(){
	string res="";

	return res;
}