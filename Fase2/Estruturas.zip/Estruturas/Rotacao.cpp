#include "Rotacao.h"
#include <iostream>

using namespace std;


Rotacao::Rotacao() : Operacao() {
}


Rotacao::Rotacao(float x, float y, float z, float angulo)
      : Operacao(x, y, z){ this->angulo = angulo; }


float Rotacao::getAngulo(){
	return angulo;
}


void Rotacao::setAngulo(float a){
	angulo=a;
}

void Rotacao::aplicaOperacao(){
	//glRotatef(angulo,getX(),getY(),getZ());
}

string Rotacao::toString(){
	string res= "";
	cout << "Rotacao:		X: " << getX() << "	Y: " << getY() << "	Z: " << getZ() << "	Ang: " << angulo << endl;

	return res;
}