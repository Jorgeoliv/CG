#ifndef UNTITLED_CAMERA_H
#define UNTITLED_CAMERA_H

#include <string>
#include "Ponto.h"
#include <math.h>
#include <GL/glut.h>

class Camera{



    float alpha;
    float beta;
    int mouseX;
    int mouseY;
    int mouseTracking;
    Ponto* posicao;
    float angulo;
    float raio;



public:
    Camera();
    Camera(float r);
    void atualizaPosicao(float r, float a, float b);
    void mouseButtons(int button, int state, int xx, int yy);
    void mouseMotion(int xx, int yy);
    void normalKeys(unsigned char c, int xx, int yy);
    void specialKeys(int key, int xx, int yy);
    void afastarCamera();
    void aproximarCamera();
    Ponto* getPosicao();
    void rodarCima();
    void rodarBaixo();
    void rodarDireita();
    void rodarEsquerda();
    void incSpeed();
    void decSpeed();
};
#endif