#include "Camera.h"


Camera::Camera(float r){

    posicao = new Ponto(10.0f,0.0f,0.0f);
    alpha = 90;
    beta  = 0;
    mouseX = -1;
    mouseY = -1;
    mouseTracking = 0;
    raio  = r;
    angulo=3;

}


Ponto* Camera::getPosicao() {

    return posicao;
}


void Camera::atualizaPosicao(float r, float a, float b){

    float camX = r * sin(a * 3.14 / 180.0) * cos(b * 3.14 / 180.0);
    float camY = r * 					     sin(b * 3.14 / 180.0);
    float camZ = r * cos(a * 3.14 / 180.0) * cos(b * 3.14 / 180.0);
    posicao->setX(camX);
    posicao->setY(camY);
    posicao->setZ(camZ);
}


void Camera::mouseButtons(int button, int state, int xx, int yy) {

    if (state == GLUT_DOWN)  {
        mouseX = xx;
        mouseY = yy;
        if (button == GLUT_LEFT_BUTTON)
            mouseTracking = 1;
        else if (button == GLUT_RIGHT_BUTTON)
            mouseTracking = 2;
        else
            mouseTracking = 0;
    }
    else if (state == GLUT_UP) {
        if (mouseTracking == 1) {
            alpha -= (xx - mouseX);
            beta += (yy - mouseY);
        }
        else if (mouseTracking == 2) {

            raio -= yy - mouseY;
            if (raio < 10.0)
                raio = 10.0;
        }
        mouseTracking = 0;
    }
}


void Camera::mouseMotion(int xx, int yy) {

    float deltaX, deltaY;
    float alphaAux, betaAux;
    float rAux;

    if (!mouseTracking)
        return;

    deltaX = xx - mouseX;
    deltaY = yy - mouseY;

    if (mouseTracking == 1) {


        alphaAux = alpha - deltaX;
        betaAux = beta + deltaY;

        if (betaAux > 85.0)
            betaAux = 85.0;
        else if (betaAux < -85.0)
            betaAux = -85.0;

        rAux = raio;
    }
    else if (mouseTracking == 2) {

        alphaAux = alpha;
        betaAux = beta;
        rAux = raio - deltaY;

    }
    atualizaPosicao(rAux, alphaAux, betaAux);
}


void Camera::normalKeys(unsigned char c, int xx, int yy) {

    switch (c) {
        case 27:
            exit(0);

        case '+':
            raio = raio + 0.5;
            break;

        case '-':
            raio = raio - 0.5;
            break;
    }

    atualizaPosicao(raio, alpha, beta);
}


void Camera::specialKeys(int key, int xx, int yy) {

    switch (key) {

        case GLUT_KEY_RIGHT:
            alpha += angulo;
            break;

        case GLUT_KEY_LEFT:
            alpha -= angulo;
            break;

        case GLUT_KEY_UP:
            beta += angulo;
            break;

        case GLUT_KEY_DOWN:
            beta -= angulo;
            break;

        case GLUT_KEY_PAGE_DOWN:
            angulo = angulo * 0.67f;
            printf("DECSPEED: %f",angulo);
            break;

        case GLUT_KEY_PAGE_UP:
            angulo = angulo * 1.5f;
            printf("INCSPEED: %f \n",angulo);
            break;
    }

    atualizaPosicao(raio, alpha, beta);
}
