#include "Operacao.h"
#include <iostream>

using namespace std;


Operacao::Operacao() {
}



float Operacao::getX(){
	return x;
}


float Operacao::getY(){
	return y;
}


float Operacao::getZ(){
	return z;
}

float Operacao::setX(float a){
	x=a;
}
 

float Operacao::setY(float a){
	y=a;
}


float Operacao::setZ(float a){
	z=a;
}

string Operacao::toString(){
	string res="";

	return res;
}