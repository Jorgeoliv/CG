#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <math.h>
#include "Ponto.h"
using namespace std;

vector<Ponto*> torus(float raioTubo, float raioMaior, int fatias, int camadas){

    Ponto* p;
    vector<Ponto*> pontos;

    float alpha = 2*M_PI / fatias;
    float beta = 2*M_PI / camadas;

    float x1, x2, x3, x4, y1, y2, z1, z2, y3, y4;

    for(int i = 0; i<fatias; i++){
        for(int j = 0; j<camadas; j++){


            z1 = raioTubo*sin(beta*j);
            z2 = raioTubo*sin(beta*(j+1));

            y1 = (raioMaior + raioTubo*cos(beta*j))*sin(alpha*i);
            y2 = (raioMaior + raioTubo*cos(beta*j))*sin(alpha*(i+1));
            y3 = (raioMaior + raioTubo*cos(beta*(j+1)))*sin(alpha*i);
            y4 = (raioMaior + raioTubo*cos(beta*(j+1)))*sin(alpha*(i+1));

            x1 = (raioMaior + raioTubo*cos(beta*j))*cos(alpha*i);
            x2 = (raioMaior + raioTubo*cos(beta*j))*cos(alpha*(i+1));
            x3 = (raioMaior + raioTubo*cos(beta*(j+1)))*cos(alpha*i);
            x4 = (raioMaior + raioTubo*cos(beta*(j+1)))*cos(alpha*(i+1));

            //glBegin(GL_TRIANGLES);
            p = new Ponto(x1,y1,z1);
            pontos.push_back(p);
                //glVertex3f(x1, y1, z1);
            p = new Ponto(x2,y2,z1);
            pontos.push_back(p);
                //glVertex3f(x2, y2, z1);
            p = new Ponto(x3,y3,z2);
            pontos.push_back(p);
                //glVertex3f(x3, y3, z2);

            p = new Ponto(x3,y3,z2);
            pontos.push_back(p);
                //glVertex3f(x3, y3, z2);
            p = new Ponto(x2,y2,z1);
            pontos.push_back(p);
                //glVertex3f(x2, y2, z1);
            p = new Ponto(x4,y4,z2);
            pontos.push_back(p);
                //glVertex3f(x4, y4, z2);

            //glEnd();

        }
    }

    return pontos;

}


vector<Ponto*> cilindro(float radius, float height, int slices) {

  Ponto* p;
  vector<Ponto*> pontos;

  float alpha = 2*M_PI / slices;
  float pxA, pxD, pzA, pzD;
    for(int i=0; i<slices;i++){

        pxA = radius * sin(alpha*i);
        pxD = radius * sin(alpha*(i+1));
        pzA = radius * cos(alpha*i);
        pzD = radius * cos(alpha*(i+1));

        //glBegin(GL_TRIANGLES);

        p = new Ponto(0,0,0);
        pontos.push_back(p);
            //glVertex3f(0,0,0);
        p = new Ponto(pxD,0,pzD);
        pontos.push_back(p);
            //glVertex3f(pxD, 0, pzD);
        p = new Ponto(pxA,0,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, 0, pzA);

        p = new Ponto(pxD,0,pzD);
        pontos.push_back(p);    
            //glVertex3f(pxD, 0, pzD);
        p = new Ponto(pxD,height,pzD);
        pontos.push_back(p);
            //glVertex3f(pxD, height, pzD);
        p = new Ponto(pxA,0,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, 0, pzA);

        p = new Ponto(pxA,0,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, 0, pzA);
        p = new Ponto(pxD,height,pzD);
        pontos.push_back(p);
            //glVertex3f(pxD, height, pzD);
        p = new Ponto(pxA,height,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, height, pzA);

        p = new Ponto(0,height,0);
        pontos.push_back(p);
            //glVertex3f(0, height, 0);
        p = new Ponto(pxA,height,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, height, pzA);
        p = new Ponto(pxD,height,pzD);
        pontos.push_back(p);
            //glVertex3f(pxD, height, pzD);

        //glEnd();
    }

    return pontos;

}




vector<Ponto*> caixa(float sideX, float sideY, float sideZ, int divisions) {
    const float deltaX = sideX/divisions;           // comprimento do lado de cada divisão em X
    const float deltaY = sideY/divisions;           // comprimento do lado de cada divisão em Y
    const float deltaZ = sideZ/divisions;           // comprimento do lado de cada divisão em Z
    const float maxX = sideX/2, minX = -maxX;       // valor máximo/mínimo que a variável em X pode tomar
    const float maxY = sideY/2, minY = -maxY;       // valor máximo/mínimo que a variável em Y pode tomar
    const float maxZ = sideZ/2, minZ = -maxZ; 

    Ponto* p;
    vector<Ponto*> pontos;
    
    for(int i=0; i<divisions; i++){

        for(int j=0; j<divisions; j++){

            // base
            p = new Ponto(minX + i*deltaX, minY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, minY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + i*deltaX, minY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + i*deltaX, minY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, minY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, minY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);

            // topo
            p = new Ponto(minX + i*deltaX, maxY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + i*deltaX, maxY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, maxY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + i*deltaX, maxY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, maxY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, maxY, minZ + j*deltaZ);
            pontos.push_back(p);


            // laterais
            p = new Ponto(minX, minY + i*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + i*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + (i+1)*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + i*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + (i+1)*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + (i+1)*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);

            p = new Ponto(maxX, minY + i*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + (i+1)*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + (i+1)*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + i*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + (i+1)*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + i*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);

            p = new Ponto(minX + j*deltaX, minY + i*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + j*deltaX, minY + (i+1)*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + (i+1)*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + j*deltaX, minY + i*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + (i+1)*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + i*deltaY, minZ);
            pontos.push_back(p);

            p = new Ponto(minX + j*deltaX, minY + i*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + i*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + (i+1)*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + j*deltaX, minY + i*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + (i+1)*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + j*deltaX, minY + (i+1)*deltaY, maxZ);
            pontos.push_back(p);
        }
    }
    return pontos;
}


vector<Ponto*> cone(float raio, float altura, int slices,int camadas){

    float angulo = ((2*M_PI)/slices);
    float xA,zA,xP,zP;

    Ponto* p;
    vector<Ponto*> pontos;

    float alturaIntermedia = altura / camadas;
    
    for (int i=0; i < slices;i++) {


        xA = raio * sin(i*angulo);
        zA = raio * cos(i*angulo);


        xP = raio * sin((i+1)*angulo);
        zP = raio * cos((i+1)*angulo);

        

        p = new Ponto(0.0f, 0.0f, 0.0f);
        pontos.push_back(p);
        p = new Ponto(xP, 0.0f, zP);
        pontos.push_back(p);
        p = new Ponto(xA, 0.0f, zA);
        pontos.push_back(p);

        for(int j=0; j < camadas; j++){

            float yA = j*alturaIntermedia;
            float yCima = (j+1)*alturaIntermedia;

            float raioIntermedioCima = raio * ((altura-yCima) /altura);
            float raioIntermedioBaixo = raio * ((altura-yA) /altura);

            xA = raioIntermedioBaixo * sin(i*angulo);
            zA = raioIntermedioBaixo * cos(i*angulo);


            xP = raioIntermedioBaixo * sin((i+1)*angulo);
            zP = raioIntermedioBaixo * cos((i+1)*angulo);

            float xACima = raioIntermedioCima * sin(i*angulo);
            float zACima = raioIntermedioCima * cos(i*angulo);

            float xPCima = raioIntermedioCima * sin((i+1)*angulo);
            float zPCima = raioIntermedioCima * cos((i+1)*angulo);

            p = new Ponto(xA,yA,zA);
            pontos.push_back(p);
            p = new Ponto(xP,yA,zP);
            pontos.push_back(p);
            p = new Ponto(xPCima,yCima,zPCima);
            pontos.push_back(p);

            p = new Ponto(xA,yA,zA);
            pontos.push_back(p);
            p = new Ponto(xPCima,yCima,zPCima);
            pontos.push_back(p);
            p = new Ponto(xACima,yCima,zACima);
            pontos.push_back(p);
        }

    }

    return pontos;

}

vector<Ponto*> esfera(float raio, int fatias, int camadas){

    float alpha = (2*M_PI) / (float) fatias, beta = (M_PI) / (float) camadas;
    float x1, y1, z1, x2, y2, z2, x3, z3, x4,z4;

    vector<Ponto*> pontos;

    for(int i = 0; i<fatias; i++){

        for(int j = 0; j<camadas; j++) {

            y1 = raio * cos(beta*j);

            x1 = raio * sin(beta*j) * sin(alpha*i);
            z1 = raio * sin(beta*j) * cos(alpha*i);

            x2 = raio * sin(beta*j) * sin(alpha * (i+1));
            z2 = raio * sin(beta*j) * cos(alpha * (i+1));

            y2 = raio * cos(beta * (j+1));

            x3 = raio * sin(beta * (j+1)) * sin(alpha*i);
            z3 = raio * sin(beta * (j+1)) * cos(alpha*i);

            x4 = raio * sin(beta * (j+1)) * sin(alpha * (i+1));
            z4 = raio * sin(beta * (j+1)) * cos(alpha * (i+1));

            Ponto *p = new Ponto(x4, y2, z4);
            pontos.push_back(p);

            p = new Ponto(x2, y1, z2);
            pontos.push_back(p);

            p = new Ponto(x1, y1, z1);
            pontos.push_back(p);

            p = new Ponto(x4, y2, z4);
            pontos.push_back(p);

            p = new Ponto(x1, y1, z1);
            pontos.push_back(p);

            p = new Ponto(x3, y2, z3);
            pontos.push_back(p);

        }

    }

    return pontos;

}

vector<Ponto*> plane(float lado){

  float coord = lado/2.0f;
  vector<Ponto*> pontos;
    //Plane
    
    Ponto *p = new Ponto(-coord, 0.0f, coord);
    pontos.push_back(p);
    p = new Ponto(coord, 0.0f, -coord);
    pontos.push_back(p);
    p = new Ponto(-coord, 0.0f, -coord);
    pontos.push_back(p);
    p = new Ponto(-coord, 0.0f, coord);
    pontos.push_back(p);
    p = new Ponto(coord, 0.0f, coord);
    pontos.push_back(p);
    p = new Ponto(coord, 0.0f, -coord);
    pontos.push_back(p);
    return pontos;
}

int comparaFigura(string a){

  if(a.compare("plane")==0) return 1;
  if(a.compare("box")==0) return 2;
  if(a.compare("cone")==0) return 3;
  if(a.compare("sphere")==0) return 4;
  if(a.compare("cylinder")==0) return 5;
  if(a.compare("torus")==0) return 6;

  return 0;
}

int main (int argc, char** argv) {
  ofstream myfile;
  vector<Ponto*> pontos;
  char* nome_ficheiro;

  int aux = comparaFigura(argv[1]);
  switch(aux){
    case 1: {
      nome_ficheiro = argv[3];
      string tam(argv[2]);
      float lado = stof(tam);
      
      if(!(lado > 0)){
          printf("Erro, valor inválido do lado!\n");
          return 1;
        }

      pontos = plane(lado);
      break;
    }

    case 2: {
      nome_ficheiro = argv[6];

      string aux1(argv[2]);
      float ladoX = stof(aux1);

      if(!(ladoX > 0)){
          printf("Erro, valor inválido do lado X!\n");
          return 1;
      }

      string aux2(argv[3]);
      float ladoY = stof(aux2);

      if(!(ladoY > 0)){
          printf("Erro, valor inválido do lado Y!\n");
          return 1;
      }

      string aux3(argv[4]);
      float ladoZ = stof(aux3);

      if(!(ladoZ > 0)){
          printf("Erro, valor inválido do lado Z!\n");
          return 1;
      }

      string aux4(argv[5]);
      int divisoes = stoi(aux4);

      if(!(divisoes > 0)){
          printf("Erro, valor inválido das divisões!\n");
          return 1;
      }

      pontos = caixa(ladoX, ladoY, ladoZ, divisoes);
      break;
    }


    case 3: {
      nome_ficheiro = argv[6];
      string aux(argv[2]);
      float raio = stof(aux);

      if(!(raio > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string aux2(argv[3]);
      float altura = stof(aux2);

      if(!(altura > 0)){
          printf("Erro, valor inválido da altura!\n");
          return 1;
      }

      string aux3(argv[4]);
      int fatias = stoi(aux3);

      if(!(fatias > 0)){
          printf("Erro, valor inválido das fatias!\n");
          return 1;
      }

      string aux4(argv[5]);
      int camadas = stoi(aux4);

      if(!(camadas > 0)){
          printf("Erro, valor inválido das camadas!\n");
          return 1;
      }

      pontos = cone(raio,altura,fatias,camadas);
      break;
    }


    case 4:{
      nome_ficheiro = argv[5];

      string raio(argv[2]);
      float r = stof(raio); 

      if(!(r > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string fatias(argv[3]);
      int f = stoi(fatias);
  
      if(!(f > 0)){
          printf("Erro, valor inválido das fatias!\n");
          return 1;
      }

      string camadas(argv[4]);
      int c = stoi(camadas);


      if(!(r > 0)){
          printf("Erro, valor inválido das camadas!\n");
          return 1;
      }

      pontos = esfera(r, f, c);
      break;
    }

    case 5: {
      nome_ficheiro = argv[5];
      string aux(argv[2]);
      float raio = stof(aux);

      if(!(raio > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string aux2(argv[3]);
      float altura = stof(aux2);

      if(!(altura > 0)){
          printf("Erro, valor inválido da altura!\n");
          return 1;
      }

      string aux3(argv[4]);
      int fatias = stoi(aux3);

      if(!(fatias > 0)){
          printf("Erro, valor inválido das fatias!\n");
          return 1;
      }

      pontos = cilindro(raio,altura,fatias);
      break;
    }

    case 6: {
      nome_ficheiro = argv[6];
      string aux(argv[2]);
      float raioTubo = stof(aux);

      if(!(raioTubo > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string aux2(argv[3]);
      float raioAnel = stof(aux2);

      if(!(raioAnel > 0)){
          printf("Erro, valor inválido da altura!\n");
          return 1;
      }

      string aux3(argv[4]);
      int fatias = stoi(aux3);

      if(!(fatias > 0)){
          printf("Erro, valor inválido das fatias!\n");
          return 1;
      }

      string aux4(argv[5]);
      int camadas = stoi(aux4);

      if(!(camadas > 0)){
          printf("Erro, valor inválido das camadas!\n");
          return 1;
      }

      pontos = cone(raioTubo,raioAnel,fatias,camadas);
      break;
    }

    default: printf("Opção inválida!");return 1; 
  }
  
  myfile.open(nome_ficheiro);

  myfile << pontos.size() << endl;
  for(Ponto* p: pontos){
    
    string escreve = p->toString();
    myfile << escreve << endl;
  }

  
  myfile.close();

  return 0;
}
