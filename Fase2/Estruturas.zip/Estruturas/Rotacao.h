#ifndef __ROTACAO_H__
#define __ROTACAO_H__

#include <math.h>
#include <string>
#include <vector>

using namespace std;

class Rotacao: public Operacao {

private:
    float angulo;

public:
	Rotacao();
    Rotacao(float,float,float,float);

    float getAngulo();

    void setAngulo(float);

    string toString();
};
		

#endif