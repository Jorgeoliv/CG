#include "tinyxml2.h"
#include "Figura.h"
#include "Grupo.h"
#include "Rotacao.h"
#include "Translacao.h"
#include "Operacao.h"
#include "Escala.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

vector<Grupo*> parseFile(char*);
