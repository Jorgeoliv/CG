#include "Grupo.h"
#include <iostream>

using namespace std;


Grupo::Grupo() {
}

vector<Operacao*> Grupo::getOperacoes(){
	return operacoes;
}


vector<string> Grupo::getFicheiros(){
	return ficheiros;
}

void adicionaOperacao(Operacao* a){
	operacoes.push_back(a);
}

void adicionaFicheiro(string a){
	ficheiros.push_back(a);
}

string Grupo::toString(){
	string res="";

	return res;
}