#include "Grupo.h"
#include <iostream>

using namespace std;


Grupo::Grupo(int id) {
	this.id = id;
}

vector<Operacao*> Grupo::getOperacoes(){
	return operacoes;
}


vector<Figura*> Grupo::getFiguras(){
	return figuras;
}

vector<Grupo*> Grupo::getGrupos(){
	return grupos;
}

void adicionaOperacao(Operacao* a){
	operacoes.push_back(a);
}

void adicionaFigura(Figura* a){
	figuras.push_back(a);
}


void adicionafigura(Grupo* a){
	grupos.push_back(a);
}

string Grupo::toString(){
	string res="";

	return res;
}