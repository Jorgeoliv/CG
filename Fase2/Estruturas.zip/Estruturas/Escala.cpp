#include "Escala.h"
#include <iostream>

using namespace std;


Escala::Escala() : Operacao() {
}


Escala::Escala(float x, float y, float z)
      : Operacao(x, y, z) { }


void Escala::aplicaOperacao(){
	//glScalef(getX(),getY(),getZ());
}



string Escala::toString(){
	string res= "";
	cout << "Escala:		X: " << getX() << "	Y: " << getY() << "	Z: " << getZ() << endl;

	return res;
}