#include "Escala.h"
#include <iostream>

using namespace std;


Escala::Escala() : Operacao() {
}


Escala::Escala(float x, float y, float z)
      : Operacao(x, y, z) { }


string Escala::toString(){
	string res="";

	return res;
}