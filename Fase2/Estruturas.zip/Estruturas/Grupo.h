#ifndef __GRUPO_H__
#define __GRUPO_H__

#include <math.h>
#include <string>
#include <vector>

using namespace std;

class Grupo {

private:
	int id;
    vector<Operacao*> operacoes;
    vector<Figura> figuras;
    vector<Grupo> grupos;

public:
	Grupo(int);

    vector<Operacao*> getOperacoes();
    vector<Figura*> getFiguras();
    vector<Grupo*> getGrupos();

    void adicionaOperacao(Operacao*);
    void adicionaFigura(Figura*);
    void adicionaGrupo(Grupo*);

    string toString();
};
		

#endif
