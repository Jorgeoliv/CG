#ifndef __GRUPO_H__
#define __GRUPO_H__

#include <math.h>
#include <string>
#include <vector>

using namespace std;

class Grupo {

private:
    vector<Operacao*> operacoes;
    vector<string> ficheiros;
    vector<Grupo> grupos;

public:
	Grupo();

    vector<Operacao*> getOperacoes();
    vector<string> getFicheiros();
    vector<Grupo> getGrupos();

    void adicionaOperacao(Operacao*);
    void adicionaFicheiro(string);
    void adicionaGrupo(Grupo);

    string toString();
};
		

#endif
