#ifndef __GRUPO_H__
#define __GRUPO_H__

#include <math.h>
#include <string>
#include <vector>

using namespace std;

class Grupo {

private:
    vector<Operacao*> operacoes;
    vector<string> ficheiros;

public:
	Grupo();

    vector<Operacao*> getOperacoes();
    vector<string> getFicheiros();

    void adicionaOperacao(Operacao*);
    void adicionaFicheiro(string);

    string toString();
};
		

#endif