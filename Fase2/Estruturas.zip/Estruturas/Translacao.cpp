#include "Translacao.h"
#include <iostream>

using namespace std;


Translacao::Translacao() : Operacao() {
}


Translacao::Translacao(float x, float y, float z)
      : Operacao(x, y, z) { }


string Translacao::toString(){
	string res="";

	return res;
}