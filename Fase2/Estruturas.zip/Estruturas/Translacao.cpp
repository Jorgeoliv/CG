#include "Translacao.h"
#include <iostream>

using namespace std;


Translacao::Translacao() : Operacao() {
}


Translacao::Translacao(float x, float y, float z)
      : Operacao(x, y, z) { }


void Translacao::aplicaOperacao(){
	//glTranslatef(getX(),getY(),getZ());
}


string Translacao::toString(){
	string res= "";
	cout << "Transl:		X: " << getX() << "	Y: " << getY() << "	Z: " << getZ() << endl;

	return res;
}