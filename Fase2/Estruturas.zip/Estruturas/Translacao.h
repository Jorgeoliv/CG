#ifndef __TRANSLACAO_H__
#define __TRANSLACAO_H__

#include "Operacao.h"

using namespace std;

class Translacao: public Operacao {

private:
    

public:
	Translacao();
    Translacao(float,float,float);

    void aplicaOperacao();

    string toString();
};
		

#endif