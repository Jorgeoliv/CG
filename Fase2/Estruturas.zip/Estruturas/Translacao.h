#ifndef __TRANSLACAO_H__
#define __TRANSLACAO_H__

#include <math.h>
#include <string>
#include <vector>

using namespace std;

class Translacao: public Operacao {

private:
    

public:
	Translacao();
    Translacao(float,float,float);

    string toString();
};
		

#endif