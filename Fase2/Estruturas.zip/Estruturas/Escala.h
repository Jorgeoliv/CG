#ifndef __ESCALA_H__
#define __ESCALA_H__

#include "Operacao.h"
#include <GL/glut.h>

using namespace std;

class Escala: public Operacao {

private:
    

public:
	Escala();
    Escala(float,float,float);

    void aplicaOperacao();

    string toString();
};
		

#endif
