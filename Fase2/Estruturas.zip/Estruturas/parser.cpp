#include "parser.h"

using namespace tinyxml2;
using namespace std;

#ifndef XMLCheckResult
	#define XMLCheckResult(a_eResult) if (a_eResult != XML_SUCCESS) { printf("Error: %i\n", a_eResult);}
#endif


int numeroGrupo = 0;

Figura* extraiFicheiro(string filename){
	Figura *figura = new Figura();

	ifstream inputFileStream(filename);

	int count;

	string line;
    getline(inputFileStream, line);

    count = stoi(line);

    for(int i=0; i < count; i++){
    	getline(inputFileStream, line);

    	stringstream ss(line);
    	vector<float> numbers;

    	for(int k = 0; k < 3; k++) {
    		string aux;
    		ss >> aux;

    		float j = stof(aux);
        	numbers.push_back(j);
    	}

    	Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
    	figura->adicionaPonto(p);

    }

    return figura;


}


vector<Grupo*> parseFile(char* filename){

	XMLDocument xmlDoc;
	XMLError eResult = xmlDoc.LoadFile(filename);

	XMLCheckResult(eResult);

	vector<Figura*> figuras;

	XMLNode * pRoot = xmlDoc.FirstChild();

	if (pRoot == nullptr){
		return figuras;
	} 


	XMLElement * pElement = pRoot->FirstChildElement("model");

	while (pElement != nullptr){

		const char* cenas = pElement->Attribute("file");
		if (cenas == nullptr);// return XML_ERROR_PARSING_ATTRIBUTE;


		string fich(cenas, strlen(cenas));


		Figura* f = extraiFicheiro(fich);
		figuras.push_back(f);

		pElement = pElement->NextSiblingElement("model");
	
	}

	return figuras;
}

void parseOperacoes(XMLElement* elemento, Group* grupo){
	if(strcmp(elemento->Name(),"rotate") == 0){
		parseRotacao(elemento,grupo);
	}

	else{
 		if(strcmp(elemento->Name(),"scale") == 0){
			parseEscala(elemento,grupo);
		}
		
		else{
			if(strcmp(elemento->Name(),"translate") == 0){
				parseTranslacao(elemento,grupo);
			}
			
			else{
				break;			
			}
		}
	}
	
	elemento=elemento->NextSiblingElement();
	
	if(elemento){
		parseOperacoes(elemento,grupo);
	}
}

Grupo* parseGrupo(XMLElement* elemento){
	Grupo* res = new Grupo(numeroGrupo++);

	XMLElement* inicial = elemento;
	
	parseOperacoes(elemento,res);

	if(strcmp(elemento->Name(),"models") == 0){
		parseModelos(element, group);
	}

	else{
		if(strcmp(elemento->Name(),"group") == 0){
			while((elemento) && (strcmp(elemento->Name(),"group") == 0)){

				XMLElement elementoFilho = element->FirstChildElement();
				if(elementoFilho){
					Grupo* filho = parseGrupo(elementoFilho);
					res->adicionaGrupo(filho);
				}
				
				elemento = elemento->NextSiblingElement();
			}
		}
									
	}
	
	return res;

}
