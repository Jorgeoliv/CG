#include "parser.h"

using namespace tinyxml2;
using namespace std;

#ifndef XMLCheckResult
	#define XMLCheckResult(a_eResult) if (a_eResult != XML_SUCCESS) { printf("Error: %i\n", a_eResult);}
#endif


int numeroGrupo = 0;

Figura* extraiFicheiro(string filename){
	Figura *figura = new Figura();

	ifstream inputFileStream(filename);

	int count;

	string line;
    getline(inputFileStream, line);

    count = stoi(line);

    for(int i=0; i < count; i++){
    	getline(inputFileStream, line);

    	stringstream ss(line);
    	vector<float> numbers;

    	for(int k = 0; k < 3; k++) {
    		string aux;
    		ss >> aux;

    		float j = stof(aux);
        	numbers.push_back(j);
    	}

    	Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
    	figura->adicionaPonto(p);

    }

    return figura;


}


void parseModelos(XMLElement *elemento, Grupo* g){
	
	cout << "Estou na parseModelos" << endl;

	XMLElement * pElement = elemento->FirstChildElement("model");

	while (pElement != nullptr){

		const char* cenas = pElement->Attribute("file");
		if (cenas == nullptr);// return XML_ERROR_PARSING_ATTRIBUTE;


		string fich(cenas, strlen(cenas));


		Figura* f = extraiFicheiro(fich);
		g->adicionaFigura(f);

		cout << "Ficheiro " << fich << endl;
		pElement = pElement->NextSiblingElement("model");
	
	}
}

void parseRotacao(XMLElement* elemento,Grupo* grupo){
	

	//cout << "Estou na parseRotacao" << endl;

	if(elemento){
		float x=0,y=0,z=0,angulo=0;

		if(elemento->Attribute("angle")){
			const char* anguloAux = elemento->Attribute("angle");
			angulo = atof(anguloAux);
		}
		
		if(elemento->Attribute("X")){
			const char* xAux = elemento->Attribute("X");
			x = atof(xAux);
		}
		if(elemento->Attribute("Y")){
			const char* yAux = elemento->Attribute("Y");
			y = atof(yAux);
		}
		if(elemento->Attribute("Z")){
			const char* zAux = elemento->Attribute("Z");
			z = atof(zAux);
		}

		Rotacao* r = new Rotacao(x,y,z,angulo);
		grupo->adicionaOperacao(r);
		cout << "Rotacao" << endl;
		cout << "X: " << x << "!Y: " << y << "!Z: " << z << "!Angulo: " << angulo << endl;
	}
}

void parseTranslacao(XMLElement* elemento,Grupo* grupo){
	

	cout << "Estou na parseTranslacao" << endl;
	cout << elemento->Name() << endl;

	//XMLElement *pElement = elemento->FirstChildElement("translate");
	if(elemento){
		float x=0,y=0,z=0;
		if(elemento->Attribute("X")){
			const char* xAux = elemento->Attribute("X");
			x = atof(xAux);
		}
		if(elemento->Attribute("Y")){
			const char* yAux = elemento->Attribute("Y");
			y = atof(yAux);
		}
		if(elemento->Attribute("Z")){
			const char* zAux = elemento->Attribute("Z");
			z = atof(zAux);
		}

		Translacao* r = new Translacao(x,y,z);
		grupo->adicionaOperacao(r);
		cout << "X: " << x << "!Y: " << y << "!Z: " << z << endl;
	}
}

void parseEscala(XMLElement* elemento,Grupo* grupo){

	
	cout << "Estou na parseEscala" << endl;

	if(elemento){
		float x=1,y=1,z=1;
		
		if(elemento->Attribute("X")){
			const char* xAux = elemento->Attribute("X");
			x = atof(xAux);
		}
		if(elemento->Attribute("Y")){
			const char* yAux = elemento->Attribute("Y");
			y = atof(yAux);
		}
		if(elemento->Attribute("Z")){
			const char* zAux = elemento->Attribute("Z");
			z = atof(zAux);
		}

		Escala* r = new Escala(x,y,z);
		grupo->adicionaOperacao(r);
		cout << "X: " << x << "!Y: " << y << "!Z: " << z << endl;
	}
}

void parseOperacoes(XMLElement** elemento,Grupo* grupo){

	
	//cout << "Estou na parseOperacoes" << endl;

	if(strcmp((*elemento)->Name(),"rotate") == 0){
		parseRotacao(*elemento,grupo);
	}

	else{
 		if(strcmp((*elemento)->Name(),"scale") == 0){
			parseEscala(*elemento,grupo);
		}
		
		else{
			if(strcmp((*elemento)->Name(),"translate") == 0){
				parseTranslacao(*elemento,grupo);
			}
			
			else{
				return;			
			}
		}
	}
	
	(*elemento)=(*elemento)->NextSiblingElement();
	
	if(*elemento){
		parseOperacoes(elemento,grupo);
	}
}

Grupo* parseGrupo(XMLElement* elemento){
	Grupo* res = new Grupo(numeroGrupo++);

	XMLElement* inicial = elemento;

	//cout << "Estou na parseGrupo" << endl;
	
	parseOperacoes(&elemento,res);

	cout << elemento->Name() << endl;

	if(strcmp(elemento->Name(),"models") == 0){
		parseModelos(elemento, res);
		elemento = elemento->NextSiblingElement();
		//cout << "Fim parse Modelos!" << endl;
		// cout << elemento->Name() << endl;
	}

	while((elemento) && (strcmp(elemento->Name(),"group") == 0)){

		XMLElement *elementoFilho = elemento->FirstChildElement();
		if(elementoFilho){
			//cout << "FAZER PARSE GRUPO!" << endl;
			Grupo* filho = parseGrupo(elementoFilho);
			res->adicionaGrupo(filho);
			//cout << "FIM PARSE GRUPO" << endl;
		}
		
		elemento = elemento->NextSiblingElement();
	}			
		
	return res;
}

vector<Grupo*> parseFile(char* filename){

	XMLDocument xmlDoc;
	XMLError eResult = xmlDoc.LoadFile(filename);

	XMLCheckResult(eResult);

	//cout << "Vou iniciar" << endl;
	//cout << filename << endl;

	vector<Grupo*> grupos;

	if(eResult != 0){
		cout << "ERRO!" << endl;
		return grupos;
	}



	XMLElement * elemento = xmlDoc.FirstChildElement("scene")->FirstChildElement("group");


	//cout << "MErda" << endl;

	while (elemento != nullptr){

		XMLElement * elementoFilho = elemento->FirstChildElement();
		cout << elemento->Name() << endl;

		if(elementoFilho != nullptr){
				Grupo* grupo = parseGrupo(elementoFilho);
				//cout << "POR GRUPO " << endl;
				grupos.push_back(grupo);
		}

		elemento = elemento->NextSiblingElement("group");
	
	}

	return grupos;
}