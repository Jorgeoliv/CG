#include "parser.h"

using namespace tinyxml2;
using namespace std;

#ifndef XMLCheckResult
	#define XMLCheckResult(a_eResult) if (a_eResult != XML_SUCCESS) { printf("Error: %i\n", a_eResult);}
#endif


int numeroGrupo = 0;

Figura* extraiFicheiro(string filename){
	Figura *figura = new Figura();

	ifstream inputFileStream(filename);

	int count;

	string line;
    getline(inputFileStream, line);

    count = stoi(line);

    for(int i=0; i < count; i++){
    	getline(inputFileStream, line);

    	stringstream ss(line);
    	vector<float> numbers;

    	for(int k = 0; k < 3; k++) {
    		string aux;
    		ss >> aux;

    		float j = stof(aux);
        	numbers.push_back(j);
    	}

    	Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
    	figura->adicionaPonto(p);

    }

    return figura;


}

void parseModelos(XMLElement elemento, Group* g){
	XMLElement * pElement = elemento->FirstChildElement("model");

	while (pElement != nullptr){

		const char* cenas = pElement->Attribute("file");
		if (cenas == nullptr);// return XML_ERROR_PARSING_ATTRIBUTE;


		string fich(cenas, strlen(cenas));


		Figura* f = extraiFicheiro(fich);
		g->adicionaFigura(f);

		pElement = pElement->NextSiblingElement("model");
	
	}
}

void parseRotacao(XMLElement* elemento,Group* grupo){
	XMLElement pElement = elemento->FirstChildElement("rotate");
	if(pElement){
		const char* anguloAux = pElement->Attribute("angle");
		float angulo = atof(anguloAux);
		const char* xAux = pElement->Attribute("axisX");
		float x = atof(xAux);
		const char* yAux = pElement->Attribute("axisY");
		float y = atof(yAux);
		const char* zAux = pElement->Attribute("axisZ");
		float z = atof(zAux);

		Rotacao* r = new Rotacao(x,y,z,angulo);
		grupo->adicionaOperacao(r);
	}
}


void parseOperacoes(XMLElement* elemento, Group* grupo){
	if(strcmp(elemento->Name(),"rotate") == 0){
		parseRotacao(elemento,grupo);
	}

	else{
 		if(strcmp(elemento->Name(),"scale") == 0){
			parseEscala(elemento,grupo);
		}
		
		else{
			if(strcmp(elemento->Name(),"translate") == 0){
				parseTranslacao(elemento,grupo);
			}
			
			else{
				break;			
			}
		}
	}
	
	elemento=elemento->NextSiblingElement();
	
	if(elemento){
		parseOperacoes(elemento,grupo);
	}
}

Grupo* parseGrupo(XMLElement* elemento){
	Grupo* res = new Grupo(numeroGrupo++);

	XMLElement* inicial = elemento;
	
	parseOperacoes(elemento,res);

	if(strcmp(elemento->Name(),"models") == 0){
		parseModelos(elemento, group);
		elemento = elemento->NextSiblingElement();
	}

	else{
		if(strcmp(elemento->Name(),"group") == 0){
			while((elemento) && (strcmp(elemento->Name(),"group") == 0)){

				XMLElement elementoFilho = elemento->FirstChildElement();
				if(elementoFilho){
					Grupo* filho = parseGrupo(elementoFilho);
					res->adicionaGrupo(filho);
				}
				
				elemento = elemento->NextSiblingElement();
			}
		}									
	}
	
	return res;

}

vector<Grupo*> parseFile(char* filename){

	XMLDocument xmlDoc;
	XMLError eResult = xmlDoc.LoadFile(filename);

	XMLCheckResult(eResult);

	vector<Grupo*> grupos;

	XMLElement * elemento = xmlDoc.FirstChildElement("scene")->FirstChildElement("group");

	while (elemento != nullptr){

		XMLElement elementoFilho = elemento->FirstChildElement();

		if(elementoFilho){
				Grupo* grupo = parseGrupo(elementoFilho);
				grupos.push_back(grupo);
		}

		elemento = elemento->NextSiblingElement("group");
	
	}

	return grupos;
}