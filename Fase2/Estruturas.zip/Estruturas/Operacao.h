#ifndef __OPERACAO_H__
#define __OPERACAO_H__

#include <math.h>
#include <string>
#include <vector>
#include <GL/glut.h>

using namespace std;

class Operacao {

private:
    float x;
    float y;
    float z;

    //podiamos ter um inteiro a dizer o tipo ou ter aquela cena do ENUM

public:
	Operacao();
	Operacao(float,float,float);

    float getX();
    float getY();
    float getZ();
    
    void setX(float);
	void setY(float);
	void setZ(float);

	void aplicaOperacao();

    string toString();
};
		

#endif