#include <string>
#include "Ponto.h"
#include "Camera.h"
#include <GL/glut.h>
#include "Camera.h"
#include <math.h>

Camera::Camera(){

    posicao = new Ponto(0.0f,0.0f,0.0f);
    alpha = 0;
    beta  = 0;
    raio  = 5;
    velocidade=1;

}


void Camera::afastarCamera() {

    raio = raio + 0.5;
}

void Camera::aproximarCamera() {

    raio = raio - 0.5;
}

void Camera :: rodarEsquerda() {
    alpha -= 0.1;

}

void Camera :: rodarDireita() {
    alpha += 0.1;

}

void Camera :: rodarCima() {
    beta +=0.1;

}

void Camera :: rodarBaixo() {
    beta-=0.1;


}


void Camera :: incSpeed(){
    velocidade = velocidade * 1.5;

}

void Camera :: decSpeed(){
    velocidade = velocidade * 0.5;

}


Ponto* Camera::getPosicao() {

//    printf("raio %f alpha %f beta %f",raio,alpha,beta);


    float camX = raio * cos(beta) * sin(alpha);
    float camY = raio * sin(beta);
    float camZ = raio * cos(beta) * cos(alpha);
    posicao->setX(camX);
    posicao->setY(camY);
    posicao->setZ(camZ);

    return posicao;


}
