//
// Created by carlos on 02-04-2018.
//

#ifndef UNTITLED_CAMERA_H
#define UNTITLED_CAMERA_H
#include <string>
#include "Ponto.h"
#include <GL/glut.h>

class Camera{



    float alpha;
    float beta;
    Ponto* posicao;
    float velocidade;
    float raio;





        public:
        Camera();
        void afastarCamera();
        Ponto* Camera::getPosicao();
};
