

#include<stdio.h>
#include<stdlib.h>

#define _USE_MATH_DEFINES
#include <math.h>
#include <vector>

#include <IL/il.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glew.h>
#include <GL/glut.h>
#endif

#define ANG2RAD M_PI/180.0 

#define COWBOYS 8
#define RAIO_COWBOYS 5
#define INDIOS 16
#define RAIO_INDIOS 25
#define ARVORES 1000
#define STEP_COWBOY 1.0f
#define STEP_INDIO 0.5f


float step = 0.0;

float height = 2.0f;
float x = 0.0f;
float z = 0.0f;
float translaX=0.0f;
float translaY=0.0f;
float translaZ=0.0f;
float rodaAng=0.0f;

float camX = 00, camY = 30, camZ = 40;
int startX, startY, tracking = 0;

int alpha = 0, beta = 45, r = 50;
float distancias[8]={
        5,
        8.75,
        12.5,
        18.75,
        62.5,
        118.75,
        237.5,
        375,


};



GLuint buffers[1];
int tamX;
int tamZ;

void changeSize(int w, int h) {

	// Prevent a divide by zero, when window is too short
	// (you cant make a window with zero width).
	if(h == 0)
		h = 1;

	// compute window's aspect ratio 
	float ratio = w * 1.0 / h;

	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	// Set the viewport to be the entire window
    glViewport(0, 0, w, h);

	// Set the correct perspective
	gluPerspective(45,ratio,1,1000);

	// return to the model view matrix mode
	glMatrixMode(GL_MODELVIEW);
}


void desenhaSol(){

        glPushMatrix();
        glColor3f(1,1,0);
        glutWireSphere(2,25,25);
        glPopMatrix();
}


void desenhaPlanetas() {

    for (int i=0; i< 8;i++) {

        glPushMatrix();
        glColor3f(i*1*0.1,1,i*0.5);
        glTranslatef(distancias[i],0,0);
        glutWireSphere(1,25,25);
        glPopMatrix();
    }


}


void renderScene(void) {

	float pos[4] = {-1.0, 1.0, 1.0, 0.0};

	glClearColor(0.0f,0.0f,0.0f,0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();
    gluLookAt(30.0+translaX,30.0+translaY,100.0+translaZ,
              0.0,0.0,0.0,
              0.0f,1.0f,0.0f);

    glBegin(GL_LINES);
    glColor3f(0,1,0);
    glVertex3f(0.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 10.0f, 0.0f);
    glColor3f(0,1,1);
    glVertex3f(0.0f, 0.0f, 0.0f);
    glVertex3f(10.0f, 0.0f, 0.0f);
    glColor3f(1,0,1);
    glVertex3f(0.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 0.0f, 10.0f);

    glEnd();

    //mostraGrelha();
	//drawScene();
    desenhaSol();
    desenhaPlanetas();
   // drawCowboys();
	step++;

// End of frame
	glutSwapBuffers();
}




// escrever fun��o de processamento do teclado

void processKeys(unsigned char key, int xx, int yy) {

}

void processa_teclado (unsigned char key, int x, int y){

    glutPostRedisplay();

    switch(key){

        case('a'): translaX += 10.0f;break;
        case('w'): translaY += 10.0f;break;
        case('s'): translaY -= 10.0f;break;
        case('d'): translaX -= 10.0f;break;
        case('r'): rodaAng += 30; break;
        default: break;
    }

}



void processMouseButtons(int button, int state, int xx, int yy) {
	
	if (state == GLUT_DOWN)  {
		startX = xx;
		startY = yy;
		if (button == GLUT_LEFT_BUTTON)
			tracking = 1;
		else if (button == GLUT_RIGHT_BUTTON)
			tracking = 2;
		else
			tracking = 0;
	}
	else if (state == GLUT_UP) {
		if (tracking == 1) {
			alpha += (xx - startX);
			beta += (yy - startY);
		}
		else if (tracking == 2) {
			
			r -= yy - startY;
			if (r < 3)
				r = 3.0;
		}
		tracking = 0;
	}
}


void processMouseMotion(int xx, int yy) {

	int deltaX, deltaY;
	int alphaAux, betaAux;
	int rAux;

	if (!tracking)
		return;

	deltaX = xx - startX;
	deltaY = yy - startY;

	if (tracking == 1) {


		alphaAux = alpha + deltaX;
		betaAux = beta + deltaY;

		if (betaAux > 85.0)
			betaAux = 85.0;
		else if (betaAux < -85.0)
			betaAux = -85.0;

		rAux = r;
	}
	else if (tracking == 2) {

		alphaAux = alpha;
		betaAux = beta;
		rAux = r - deltaY;
		if (rAux < 3)
			rAux = 3;
	}
	camX = rAux * sin(alphaAux * 3.14 / 180.0) * cos(betaAux * 3.14 / 180.0);
	camZ = rAux * cos(alphaAux * 3.14 / 180.0) * cos(betaAux * 3.14 / 180.0);
	camY = rAux * 							     sin(betaAux * 3.14 / 180.0);
}


void init() {

// Colocar aqui load da imagem que representa o mapa de alturas




// alguns settings para OpenGL
	glEnable(GL_DEPTH_TEST);
	//glEnable(GL_CULL_FACE);
}


int main(int argc, char **argv) {

// inicializa��o
	glutInit(&argc, argv);

    glutCreateWindow("CG@DI-UM");

    GLenum err = glewInit();
    if(GLEW_OK != err){
        printf("ERRO NO GLEW!Mensagem: %s\n", glewGetErrorString(err));
        return 0;
    }

	glutInitDisplayMode(GLUT_DEPTH|GLUT_DOUBLE|GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(320,320);

    glutCreateWindow("CG@DI-UM");
// registo de fun��es 
	glutDisplayFunc(renderScene);
	glutIdleFunc(renderScene);
	glutReshapeFunc(changeSize);

// p�r aqui registo da fun��es do teclado e rato

    glutKeyboardFunc(processa_teclado);
	glutMouseFunc(processMouseButtons);
	glutMotionFunc(processMouseMotion);

	init();
    //preencheGrelha(256,256);

// entrar no ciclo do GLUT 
	glutMainLoop();
	
	return 0;
}


