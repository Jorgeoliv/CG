#include "parser.h"

using namespace tinyxml2;
using namespace std;

#ifndef XMLCheckResult
	#define XMLCheckResult(a_eResult) if (a_eResult != XML_SUCCESS) { printf("Error: %i\n", a_eResult); /*return a_eResult;*/ }
#endif

Figura* extraiFicheiro(string filename){
	Figura *figura = new Figura();

	ifstream inputFileStream(filename);

	int count;
    inputFileStream>>count;

    cout << count << endl;

	string line;
    getline(inputFileStream, line);

    cout << line << endl;

    for(int i=0;i<count;i++){
    	getline(inputFileStream, line);
    	//cout << line << endl;
    	stringstream ss(line);
    	vector<float> numbers;

    	for(int k = 0; k < 3; k++) {
    		string aux;
    		ss >> aux;
	//		cout << "Cenas" + aux << endl;
    		float j = stof(aux);
        	numbers.push_back(j);
        	//cout << aux << " ";
        	//cout << "" << endl;
    	}

    	Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
    	figura->adicionaPonto(p);

    }

    return figura;

    // cout << line << endl;
}


vector<Figura*> parseFile(char* filename){
	//std::cout << "Passei 0\n";
	XMLDocument xmlDoc;
	XMLError eResult = xmlDoc.LoadFile(filename);
	//std::cout << "Passei 1\n";
	XMLCheckResult(eResult);


	//std::cout << "Passei 2\n";
	XMLNode * pRoot = xmlDoc.FirstChild();
	if (pRoot == nullptr); //return XML_ERROR_FILE_READ_ERROR;


	//std::cout << "Passei 3\n";

	vector<Figura*> figuras;

	XMLElement * pElement = pRoot->FirstChildElement("model");
	if (pElement == nullptr); //return XML_ERROR_PARSING_ELEMENT;

	while (pElement != nullptr){

		const char* cenas = pElement->Attribute("file");
		if (cenas == nullptr);// return XML_ERROR_PARSING_ATTRIBUTE;


		std::cout << cenas << std::endl;

		string fich(cenas, strlen(cenas));


		Figura* f = extraiFicheiro(fich);
		figuras.push_back(f);

		pElement = pElement->NextSiblingElement("model");
	
	}

	return figuras;
}
