#include "parser.h"

using namespace tinyxml2;
using namespace std;

#ifndef XMLCheckResult
	#define XMLCheckResult(a_eResult) if (a_eResult != XML_SUCCESS) { printf("Error: %i\n", a_eResult);}
#endif


Figura* extraiFicheiro(string filename){
	Figura *figura = new Figura();

	ifstream inputFileStream(filename);

	int count;

	string line;
    getline(inputFileStream, line);

    count = stoi(line);

    for(int i=0; i < count; i++){
    	getline(inputFileStream, line);

    	stringstream ss(line);
    	vector<float> numbers;

    	for(int k = 0; k < 3; k++) {
    		string aux;
    		ss >> aux;

    		float j = stof(aux);
        	numbers.push_back(j);
    	}

    	Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
    	figura->adicionaPonto(p);

    }

    return figura;


}


vector<Figura*> parseFile(char* filename){

	XMLDocument xmlDoc;
	XMLError eResult = xmlDoc.LoadFile(filename);

	XMLCheckResult(eResult);

	vector<Figura*> figuras;

	XMLNode * pRoot = xmlDoc.FirstChild();

	if (pRoot == nullptr){
		return figuras;
	} 


	XMLElement * pElement = pRoot->FirstChildElement("model");

	while (pElement != nullptr){

		const char* cenas = pElement->Attribute("file");
		if (cenas == nullptr);// return XML_ERROR_PARSING_ATTRIBUTE;


		string fich(cenas, strlen(cenas));


		Figura* f = extraiFicheiro(fich);
		figuras.push_back(f);

		pElement = pElement->NextSiblingElement("model");
	
	}

	return figuras;
}
