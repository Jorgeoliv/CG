#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <math.h>
#include "Ponto.h"
using namespace std;




vector<Ponto*> cubo(float side, int divisions) {
    const float divisionSide = side/divisions;      // comprimento do lado de cada divisão
    const float max = side/2, min = -max;           // valor máximo/mínimo que a variável pode tomar
    float i1=min, j1=min, i2, j2;

    Ponto* p;
    vector<Ponto*> pontos;  

    for(int i=1; i<=divisions; i++){
        i2 = min + i*divisionSide;

        for(int j=1; j<=divisions; j++){
            j2 = min + j*divisionSide;

            // base
            p = new Ponto(i1, min, j1);
            pontos.push_back(p);
            p = new Ponto(i2, min, j2);
            pontos.push_back(p);
            p = new Ponto(i1, min, j2);
            pontos.push_back(p);
            p = new Ponto(i1, min, j1);
            pontos.push_back(p);
            p = new Ponto(i2, min, j1);
            pontos.push_back(p);
            p = new Ponto(i2, min, j2);
            pontos.push_back(p);

            // topo
            p = new Ponto(i1, max, j1);
            pontos.push_back(p);
            p = new Ponto(i1, max, j2);
            pontos.push_back(p);
            p = new Ponto(i2, max, j2);
            pontos.push_back(p);
            p = new Ponto(i1, max, j1);
            pontos.push_back(p);
            p = new Ponto(i2, max, j2);
            pontos.push_back(p);
            p = new Ponto(i2, max, j1);
            pontos.push_back(p);

            // laterais
            p = new Ponto(min, i1, j1);
            pontos.push_back(p);
            p = new Ponto(min, i1, j2);
            pontos.push_back(p);
            p = new Ponto(min, i2, j2);
            pontos.push_back(p);
            p = new Ponto(min, i1, j1);
            pontos.push_back(p);
            p = new Ponto(min, i2, j2);
            pontos.push_back(p);
            p = new Ponto(min, i2, j1);
            pontos.push_back(p);  

            p = new Ponto(max, i1, j1);
            pontos.push_back(p);
            p = new Ponto(max, i2, j1);
            pontos.push_back(p);
            p = new Ponto(max, i2, j2);
            pontos.push_back(p);
            p = new Ponto(max, i1, j1);
            pontos.push_back(p);
            p = new Ponto(max, i2, j2);
            pontos.push_back(p);
            p = new Ponto(max, i1, j2);
            pontos.push_back(p); 

            p = new Ponto(j1, i1, min);
            pontos.push_back(p);
            p = new Ponto(j1, i2, min);
            pontos.push_back(p);
            p = new Ponto(j2, i2, min);
            pontos.push_back(p);
            p = new Ponto(j1, i1, min);
            pontos.push_back(p);
            p = new Ponto(j2, i2, min);
            pontos.push_back(p);
            p = new Ponto(j2, i1, min);
            pontos.push_back(p); 

            p = new Ponto(j1, i1, max);
            pontos.push_back(p);
            p = new Ponto(j2, i1, max);
            pontos.push_back(p);
            p = new Ponto(j2, i2, max);
            pontos.push_back(p);
            p = new Ponto(j1, i1, max);
            pontos.push_back(p);
            p = new Ponto(j2, i2, max);
            pontos.push_back(p);
            p = new Ponto(j1, i2, max);
            pontos.push_back(p);

            j1 = j2;
        }
        j1 = min;
        i1 = i2;
    }
    return pontos;
}


vector<Ponto*> cone(float raio, float altura, int slices,int camadas){

    float angulo = ((2*M_PI)/slices);
    float xA,zA,xP,zP;

    Ponto* p;
    vector<Ponto*> pontos;

    float alturaIntermedia = altura / camadas;
    
    for (int i=0; i < slices;i++) {


        xA = raio * sin(i*angulo);
        zA = raio * cos(i*angulo);


        xP = raio * sin((i+1)*angulo);
        zP = raio * cos((i+1)*angulo);

        

        p = new Ponto(0.0f, 0.0f, 0.0f);
        pontos.push_back(p);
        p = new Ponto(xP, 0.0f, zP);
        pontos.push_back(p);
        p = new Ponto(xA, 0.0f, zA);
        pontos.push_back(p);

        for(int j=0; j < camadas; j++){

            float yA = j*alturaIntermedia;
            float yCima = (j+1)*alturaIntermedia;

            float raioIntermedioCima = raio * ((altura-yCima) /altura);
            float raioIntermedioBaixo = raio * ((altura-yA) /altura);

            xA = raioIntermedioBaixo * sin(i*angulo);
            zA = raioIntermedioBaixo * cos(i*angulo);


            xP = raioIntermedioBaixo * sin((i+1)*angulo);
            zP = raioIntermedioBaixo * cos((i+1)*angulo);

            float xACima = raioIntermedioCima * sin(i*angulo);
            float zACima = raioIntermedioCima * cos(i*angulo);

            float xPCima = raioIntermedioCima * sin((i+1)*angulo);
            float zPCima = raioIntermedioCima * cos((i+1)*angulo);

            p = new Ponto(xA,yA,zA);
            pontos.push_back(p);
            p = new Ponto(xP,yA,zP);
            pontos.push_back(p);
            p = new Ponto(xPCima,yCima,zPCima);
            pontos.push_back(p);

            p = new Ponto(xA,yA,zA);
            pontos.push_back(p);
            p = new Ponto(xPCima,yCima,zPCima);
            pontos.push_back(p);
            p = new Ponto(xACima,yCima,zACima);
            pontos.push_back(p);
        }

    }

    return pontos;

}

vector<Ponto*> esfera(float raio, int fatias, int camadas){

    float alpha = (2*M_PI) / (float) fatias, beta = (M_PI) / (float) camadas;
    float x1, y1, z1, x2, y2, z2, x3, z3, x4,z4;

    vector<Ponto*> pontos;

    for(int i = 0; i<fatias; i++){

        for(int j = 0; j<camadas; j++) {

            y1 = raio * cos(beta*j);

            x1 = raio * sin(beta*j) * sin(alpha*i);
            z1 = raio * sin(beta*j) * cos(alpha*i);

            x2 = raio * sin(beta*j) * sin(alpha * (i+1));
            z2 = raio * sin(beta*j) * cos(alpha * (i+1));

            y2 = raio * cos(beta * (j+1));

            x3 = raio * sin(beta * (j+1)) * sin(alpha*i);
            z3 = raio * sin(beta * (j+1)) * cos(alpha*i);

            x4 = raio * sin(beta * (j+1)) * sin(alpha * (i+1));
            z4 = raio * sin(beta * (j+1)) * cos(alpha * (i+1));

            // glColor3f(0.0,0.0,1.0f);

            //glVertex3f(x4, y2, z4);
            Ponto *p = new Ponto(x4, y2, z4);
            pontos.push_back(p);
            //glVertex3f(x2, y1, z2);
            p = new Ponto(x2, y1, z2);
            pontos.push_back(p);
            //glVertex3f(x1, y1, z1);
            p = new Ponto(x1, y1, z1);
            pontos.push_back(p);

            //glVertex3f(x4, y2, z4);
            p = new Ponto(x4, y2, z4);
            pontos.push_back(p);
            //glVertex3f(x1, y1, z1);
            p = new Ponto(x1, y1, z1);
            pontos.push_back(p);
            //glVertex3f(x3, y2, z3);
            p = new Ponto(x3, y2, z3);
            pontos.push_back(p);

        }

    }

    return pontos;

}

vector<Ponto*> plane(float lado){

	float coord = lado/2.0f;
	vector<Ponto*> pontos;
    //Plane
    
    Ponto *p = new Ponto(-coord, 0.0f, coord);
    pontos.push_back(p);
  	p = new Ponto(coord, 0.0f, -coord);
  	pontos.push_back(p);
    p = new Ponto(-coord, 0.0f, -coord);
    pontos.push_back(p);
    p = new Ponto(-coord, 0.0f, coord);
    pontos.push_back(p);
  	p = new Ponto(coord, 0.0f, coord);
  	pontos.push_back(p);
    p = new Ponto(coord, 0.0f, -coord);
    pontos.push_back(p);
    return pontos;
}

int comparaFigura(string a){

	if(a.compare("plane")==0) return 1;
  if(a.compare("cube")==0) return 2;
  if(a.compare("cone")==0) return 3;
  if(a.compare("sphere")==0) return 4;

	return 0;
}

int main (int argc, char** argv) {
  ofstream myfile;
  vector<Ponto*> pontos;

  int aux = comparaFigura(argv[1]);
  switch(aux){
  	case 1: {
  		myfile.open(argv[3]);
  		string tam(argv[2]);
  		float lado = stof(tam);
  		
  		if(!(lado > 0)){
      		printf("Erro, valor inválido do lado!\n");
      		return 1;
      	}

  		pontos = plane(lado);
  		break;
  	}

    case 2: {
      myfile.open(argv[4]);

      string aux1(argv[2]);
      float lado = stof(aux1);

      if(!(lado > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string aux2(argv[3]);
      int divisoes = stoi(aux2);

      if(!(divisoes > 0)){
          printf("Erro, valor inválido da altura!\n");
          return 1;
      }

      pontos = cubo(lado,divisoes);
      break;
    }


    case 3: {
      myfile.open(argv[6]);
      string aux(argv[2]);
      float raio = stof(aux);

      if(!(raio > 0)){
      		printf("Erro, valor inválido do raio!\n");
      		return 1;
      }

      string aux2(argv[3]);
      float altura = stof(aux2);

      if(!(altura > 0)){
      		printf("Erro, valor inválido da altura!\n");
      		return 1;
      }

      string aux3(argv[4]);
      int fatias = stoi(aux3);

    	if(!(fatias > 0)){
      		printf("Erro, valor inválido das fatias!\n");
      		return 1;
      }

      string aux4(argv[5]);
      int camadas = stoi(aux4);

      if(!(camadas > 0)){
      		printf("Erro, valor inválido das camadas!\n");
      		return 1;
      }

      pontos = cone(raio,altura,fatias,camadas);
      break;
    }


    case 4:{
      myfile.open(argv[5]);

      string raio(argv[2]);
      float r = stof(raio); // Nao podia fazer logo stof(argv[2])

      if(!(r > 0)){
      		printf("Erro, valor inválido do raio!\n");
      		return 1;
      }

      string fatias(argv[3]);
      int f = stoi(fatias);
	
      if(!(f > 0)){
      		printf("Erro, valor inválido das fatias!\n");
      		return 1;
      }

      string camadas(argv[4]);
      int c = stoi(camadas);


      if(!(r > 0)){
      		printf("Erro, valor inválido das camadas!\n");
      		return 1;
      }

      pontos = esfera(r, f, c);
      break;
    }

  	default: break; 
  }
  
  myfile << pontos.size() << endl;
  for(Ponto* p: pontos){
    
    string escreve = p->toString();
    myfile << escreve << endl;
  }

  
  myfile.close();

  return 0;
}
