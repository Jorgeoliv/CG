#include "tinyxml2.h"
#include "Figura.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

vector<Figura*> parseFile(char*);
