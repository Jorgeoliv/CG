#include "tinyxml2.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include "Ponto.h"
#include "Patch.h"

Patch* extraiPatch(std::string filename);

