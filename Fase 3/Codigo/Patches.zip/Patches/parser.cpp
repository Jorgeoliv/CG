#include "parser.h"

using namespace tinyxml2;
using namespace std;

#ifndef XMLCheckResult
	#define XMLCheckResult(a_eResult) if (a_eResult != XML_SUCCESS) { printf("Error: %i\n", a_eResult);}
#endif


int numeroGrupo = 0;

Patch* extraiPatch(string filename){

	ifstream inputFileStream(filename);

	int count;

	string line;
    getline(inputFileStream, line);

    count = stoi(line);
    vector<vector<int>> indices;
    for(int i=0; i < count; i++){
    	getline(inputFileStream, line);

    	stringstream ss(line);
    	vector<int> numbers;

    	for(int k = 0; k < 16; k++) {
    		string aux;
    		ss >> aux;

    		int j = stoi(aux);
        	numbers.push_back(j);
        	//cout << "IND: " << j << endl;
    	}

    	indices.push_back(numbers);
    }

    getline(inputFileStream, line);
	count = stoi(line);

	cout << "Pontos: " << count << endl;    

	vector<Ponto*> pontosControlo;

	for(int i=0; i < count; i++){
    	getline(inputFileStream, line);

    	stringstream ss(line);
    	vector<float> numbers;

    	for(int k = 0; k < 3; k++) {
    		string aux;
    		ss >> aux;

    		float j = stof(aux);
        	numbers.push_back(j);
    	}

    	Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
    	pontosControlo.push_back(p);

    }

    cout << "Tam: " << pontosControlo.size() << endl;

    Patch* res = new Patch(indices,pontosControlo);
    return res;

}
