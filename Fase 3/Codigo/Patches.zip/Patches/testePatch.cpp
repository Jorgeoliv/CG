#include "parser.h"

using namespace std;

int main(int argc, char** argv){
	
	printf("%s\n",argv[1]);
	string aux = string(argv[1]);
	Patch* p = extraiPatch(aux);

	vector<vector<int>> indices = p->getIndices();
	vector<Ponto*> pontos = p->getPontos();

	int i = 0;
	for(vector<int> ind: indices){
		cout << "Indice: " << i << endl;
		for(int k: ind){
			cout << "Valor: " << k << " !";
		}
	
		cout << endl;
		i++;
	}
	
	i = 0;

	for(Ponto* pon: pontos){
		cout << "Ponto: " << i << endl;
	
		cout << "Valor: " << pon->toString() << " !" << endl;

		i++;
	}
	return 0;
}
