#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#define _USE_MATH_DEFINES
#include <math.h>
#include "parser.h"
#include "Camera.h"

using namespace std;


Camera* camera;

Grupo* cena;

void changeSize(int w, int h) {

    // Prevent a divide by zero, when window is too short
    // (you cant make a window with zero width).
    if(h == 0)
        h = 1;

    // compute window's aspect ratio
    float ratio = w * 1.0 / h;

    // Set the projection matrix as current
    glMatrixMode(GL_PROJECTION);
    // Load Identity Matrix
    glLoadIdentity();

    // Set the viewport to be the entire window
    glViewport(0, 0, w, h);

    // Set perspective
    gluPerspective(45.0f ,ratio, 1.0f ,1000.0f);

    // return to the model view matrix mode
    glMatrixMode(GL_MODELVIEW);
}


void imprimeFigura(vector<Figura*> figuras){

    glColor3f(1,1,1);
    glBegin(GL_TRIANGLES);

    //cout << "Imprimindo figura" << endl;

    for(Figura* f: figuras){

        vector<Ponto*> pontos = f->getPontos();


        for (Ponto *p: pontos) {

            glVertex3d(p->getX(), p->getY(), p->getZ());
        }

    }

    glEnd();

}

void imprimeGrupo(Grupo* g){

    //cout << "Vou imprimir grupo" << endl;
    //if(g->getID() < 6 && g->getID()!=0) return;

    glPushMatrix();

    vector<Operacao*> operacoes = g->getOperacoes();
    for(Operacao* op: operacoes){
      //  cout << "Operacao" << endl;
        op->aplicaOperacao();
    }


    vector<Figura*> figuras = g->getFiguras();
    imprimeFigura(figuras);

    vector<Grupo*> gruposFilhos = g->getGrupos();
    for(Grupo* filho: gruposFilhos){
        imprimeGrupo(filho);
    }

    glPopMatrix();

}

void percorreGrupos(){

    imprimeGrupo(cena);
    
}


void renderScene(void) {

    // clear buffers

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);

    glLoadIdentity();

    // set the camera
    Ponto* pos = camera->getPosicao();

    gluLookAt(pos->getX(),pos->getY(),pos->getZ(),
              0.0,0.0,0.0,
              0.0f,1.0f,0.0f);

    percorreGrupos();

    // End of frame
    glutSwapBuffers();
}


void processKeys(unsigned char c, int xx, int yy) {

    camera->normalKeys(c, xx, yy);

    switch(c){

        case('p'): glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);break;//visualizacao por pontos
        case('t'): glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);break;//visualizacao total
        case('l'): glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);break;//visualizacao por linhas
    }
}


void processSpecialKeys(int key, int xx, int yy) {

    camera->specialKeys(key, xx, yy);
}


void processMouseButtons(int button, int state, int xx, int yy) {

    camera->mouseButtons(button, state, xx, yy);
}


void processMouseMotion(int xx, int yy) {

    camera->mouseMotion(xx, yy);
}



int main(int argc, char **argv) {

    if(argc < 2){
        cout << "ERRO! Poucos argumentos." << endl;
        return 0;

    }

    cena = (parseFile(argv[1]));

    cout << "Fim parse xml" << endl;
    if((cena) == nullptr){
        printf("Erro no parsing!\n");
        return 1;
    }


// init GLUT and the window
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DEPTH|GLUT_DOUBLE|GLUT_RGBA);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(800,800);
    glutCreateWindow("CG-TP@DI-UM");
    camera = new Camera(10.0);

// Required callback registry
    glutIdleFunc(renderScene);
    glutDisplayFunc(renderScene);
    glutReshapeFunc(changeSize);

// Callback registration for keyboard processing
    glutKeyboardFunc(processKeys);
    glutSpecialFunc(processSpecialKeys);
    glutMouseFunc(processMouseButtons);
    glutMotionFunc(processMouseMotion);

//  OpenGL settings
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);




// enter GLUT's main cycle
    glutMainLoop();



    return 1;
}
