#ifndef UNTITLED_CAMERA_H
#define UNTITLED_CAMERA_H

#include <string>
#include "Ponto.h"
#include <math.h>
#include <GL/glut.h>

class Camera{



    float alpha;
    float beta;
    int mouseX;
    int mouseY;
    int mouseTracking;
    Ponto* posicao;
    Ponto* foco;
    float angulo;
    float velocidade;



public:
    Camera();
    Camera(float,float,float);
    void rodarCamera(float a, float b);
    void moverCamera(int a, int b, int c);
    void mouseButtons(int button, int state, int xx, int yy);
    void mouseMotion(int xx, int yy);
    void normalKeys(unsigned char c, int xx, int yy);
    void specialKeys(int key, int xx, int yy);
    Ponto* getPosicao();
    Ponto* getFoco();
};
#endif