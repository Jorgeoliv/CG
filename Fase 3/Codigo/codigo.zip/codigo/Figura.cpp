#include "Figura.h"
#include <iostream>

using namespace std;


Figura::Figura() {
}


void Figura::adicionaPonto(Ponto* p){

	pontos.push_back(p);
}

vector<Ponto*> Figura::getPontos(){
	return pontos;
}

string Figura::toString(){
	string res="";

	for(Ponto* p: pontos){
		res+= " { " + p->toString() + " } ";
	}
	return res;
}
