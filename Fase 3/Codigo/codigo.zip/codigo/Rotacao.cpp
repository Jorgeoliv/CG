#include "Rotacao.h"
#include <iostream>

using namespace std;


Rotacao::Rotacao() : Operacao() {
	tempo = 0;
}


Rotacao::Rotacao(float x, float y, float z, float angulo, float tempo)
      : Operacao(x, y, z){
	this->angulo = angulo;
	this->tempo = tempo;
}


float Rotacao::getAngulo(){
	return angulo;
}


void Rotacao::setAngulo(float a){
	angulo=a;
}

float Rotacao::getTempo(){
	return tempo;
}


void Rotacao::setTempo(float a){
	tempo=a;
}

void Rotacao::aplicaOperacao(){
	if(tempo==0){
		glRotatef(angulo,getX(),getY(),getZ());
	}

	else{

		float tempoDecorrido = glutGet(GLUT_ELAPSED_TIME);
		float percentagem = (int) tempoDecorrido % (int) (tempo * 1000);

		percentagem = percentagem / (tempo * 1000);

		glRotatef(360*percentagem,getX(),getY(),getZ());
	}
}

string Rotacao::toString(){
	string res= "";
	cout << "Rotacao:		X: " << getX() << "	Y: " << getY() << "	Z: " << getZ() << "	Ang: " << angulo << endl;

	return res;
}