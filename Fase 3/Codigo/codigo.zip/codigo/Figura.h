#ifndef __Ponto_H__
#define __Ponto_H__

#include <math.h>
#include <string>
#include <vector>

#include "Ponto.h"

using namespace std;

class Figura {

private:
    vector<Ponto*> pontos;

public:
    Figura();

    void adicionaPonto(Ponto*);
	
vector<Ponto*> getPontos();


    string toString();
};
		

#endif
