#include "Camera.h"


Camera::Camera(float x, float y, float z){

    posicao = new Ponto(x,y,z);
    foco = new Ponto(0.0f,0.0f,0.0f);
    alpha = 135;
    beta  = 0;
    mouseX = -1;
    mouseY = -1;
    mouseTracking = 0;
    angulo = 0.5;
    velocidade = 0.03;

}


Ponto* Camera::getPosicao() {

    return posicao;
}


Ponto* Camera::getFoco() {

    return foco;
}


void Camera::rodarCamera(float a, float b){

    float focoX = posicao->getX() + 10 * sin(-a * 3.14 / 180.0) * cos(-b * 3.14 / 180.0);
    float focoY = posicao->getY() + 10 * 					     sin(-b * 3.14 / 180.0);
    float focoZ = posicao->getZ() + 10 * cos(-a * 3.14 / 180.0) * cos(-b * 3.14 / 180.0);
    foco->setX(focoX);
    foco->setY(focoY);
    foco->setZ(focoZ);
}


void Camera::moverCamera(int a, int b, int c) {

    float v = velocidade;
    float dx = foco->getX() - posicao->getX();
    float dy = foco->getY() - posicao->getY();
    float dz = foco->getZ() - posicao->getZ();

    if (b == 0) {
        posicao->addPonto(a*v*dz, 0, c*v*dx);
        foco->addPonto(a*v*dz, 0, c*v*dx);
    }
    else{
        posicao->addPonto(a*v*dx, b*v*dy, c*v*dz);
        foco->addPonto(a*v*dx, b*v*dy, c*v*dz);
    }
}


void Camera::mouseButtons(int button, int state, int xx, int yy) {

    if (state == GLUT_DOWN)  {
        mouseX = xx;
        mouseY = yy;
        if (button == GLUT_LEFT_BUTTON)
            mouseTracking = 1;
        else
            mouseTracking = 0;
    }
    else if (state == GLUT_UP) {
        if (mouseTracking == 1) {
            alpha += (xx - mouseX);
            beta += (yy - mouseY);
        }
        mouseTracking = 0;
    }
}


void Camera::mouseMotion(int xx, int yy) {

    float deltaX, deltaY;
    float alphaAux, betaAux;
    float rAux;

    if (!mouseTracking)
        return;

    deltaX = xx - mouseX;
    deltaY = yy - mouseY;

    if (mouseTracking == 1) {


        alphaAux = alpha + deltaX;
        betaAux = beta + deltaY;

        if (betaAux > 85.0)
            betaAux = 85.0;
        else if (betaAux < -85.0)
            betaAux = -85.0;
    }

    rodarCamera(alphaAux, betaAux);
}


void Camera::normalKeys(unsigned char c, int xx, int yy) {

    switch (c) {
        case 27:
            exit(0);

        case '+':
            velocidade *= 1.33;
            if(velocidade > 0.5)
                velocidade = 0.5;
            break;

        case '-':
            velocidade *= 0.67;
            if(velocidade < 0.005)
                velocidade = 0.01;
            break;

        case 'w':
            moverCamera(1,1,1);
            break;

        case 's':
            moverCamera(-1,-1,-1);
            break;

        case 'a':
            moverCamera(1,0,-1);
            break;

        case 'd':
            moverCamera(-1,0,1);
            break;
    }
}


void Camera::specialKeys(int key, int xx, int yy) {

    switch (key) {

        case GLUT_KEY_RIGHT:
            alpha += angulo;
            rodarCamera(alpha, beta);
            break;

        case GLUT_KEY_LEFT:
            alpha -= angulo;
            rodarCamera(alpha, beta);
            break;

        case GLUT_KEY_UP:
            beta -= angulo;
            rodarCamera(alpha, beta);
            break;

        case GLUT_KEY_DOWN:
            beta += angulo;
            rodarCamera(alpha, beta);
            break;

        case GLUT_KEY_PAGE_DOWN:
            angulo *= 0.67;
            break;

        case GLUT_KEY_PAGE_UP:
            angulo *= 1.33;
            break;
    }
}
