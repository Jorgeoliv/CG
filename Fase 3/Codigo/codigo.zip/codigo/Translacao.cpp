#include "Translacao.h"
#include <iostream>


using namespace std;


Translacao::Translacao() : Operacao() {
	upY[0] = 0.0f;
	upY[1] = 1.0f;
	upY[2] = 0.0f;
	tempo = 0;
}


Translacao::Translacao(float x, float y, float z, float t, vector<Ponto*> p)
      : Operacao(x, y, z) { 

    upY[0] = 0.0f;
	upY[1] = 1.0f;
	upY[2] = 0.0f;
	tempo = t;

	if(p.size() < 4){
		tempo = 0;
	}
	else{
		pontos = p;
	}
}


float Translacao::getTempo(){
	return tempo;
}


void Translacao::setTempo(float a){
	tempo=a;
}

vector<Ponto*> Translacao::getPontos(){
	return pontos;
}

void Translacao::setPontos(vector<Ponto*> p){
	if(p.size() > 4){
		pontos = p;
	}
}

void buildRotMatrix(float *x, float *y, float *z, float *m) {

	m[0] = x[0]; m[1] = x[1]; m[2] = x[2]; m[3] = 0;
	m[4] = y[0]; m[5] = y[1]; m[6] = y[2]; m[7] = 0;
	m[8] = z[0]; m[9] = z[1]; m[10] = z[2]; m[11] = 0;
	m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
}


void cross(float *a, float *b, float *res) {

	res[0] = a[1]*b[2] - a[2]*b[1];
	res[1] = a[2]*b[0] - a[0]*b[2];
	res[2] = a[0]*b[1] - a[1]*b[0];
}


void Translacao::normalize(float *a) {

	float l = sqrt(a[0]*a[0] + a[1] * a[1] + a[2] * a[2]);
	a[0] = a[0]/l;
	a[1] = a[1]/l;
	a[2] = a[2]/l;
}


float length(float *v) {

	float res = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
	return res;

}

void multMatrixVector(float *m, float *v, float *res) {

	for (int j = 0; j < 4; ++j) {
		res[j] = 0;
		for (int k = 0; k < 4; ++k) {
			res[j] += v[k] * m[j * 4 + k];
		}
	}

}


void Translacao::getCatmullRomPoint(float t, int* indices, float *pos, float *deriv) {

	// catmull-rom matrix
	float m[4][4] = {	{-0.5f,  1.5f, -1.5f,  0.5f},
						{ 1.0f, -2.5f,  2.0f, -0.5f},
						{-0.5f,  0.0f,  0.5f,  0.0f},
						{ 0.0f,  1.0f,  0.0f,  0.0f}
	};

	Ponto* p0 = pontos.at(indices[0]);
	Ponto* p1 = pontos.at(indices[1]);
	Ponto* p2 = pontos.at(indices[2]);
	Ponto* p3 = pontos.at(indices[3]);
	// Compute A = M * P
    float aX[4];
    float pX[4];
    pX[0] = p0->getX();
    pX[1] = p1->getX();
    pX[2] = p2->getX();
    pX[3] = p3->getX();
    multMatrixVector(*m,pX,aX);

    float aY[4];
    float pY[4];
    pY[0] = p0->getY();
    pY[1] = p1->getY();
    pY[2] = p2->getY();
    pY[3] = p3->getY();
    multMatrixVector(*m,pY,aY);


    float aZ[4];
    float pZ[4];
    pZ[0] = p0->getZ();
    pZ[1] = p1->getZ();
    pZ[2] = p2->getZ();
    pZ[3] = p3->getZ();
    multMatrixVector(*m,pZ,aZ);

    // Compute pos = T * A
	float T[4] = {t*t*t,t*t,t,1};
    float posX = 0;
    float posY = 0;
    float posZ = 0;

    for(int i = 0; i < 4; i++){
        posX += T[i]*aX[i];
        posY += T[i]*aY[i];
        posZ += T[i]*aZ[i];
    }

    pos[0] = posX;
    pos[1] = posY;
    pos[2] = posZ;


    // compute deriv = T' * A
    float TD[4] = {3*t*t,2*t,1,0};
    float derX = 0;
    float derY = 0;
    float derZ = 0;

    for(int i = 0; i < 4; i++){
        derX += TD[i]*aX[i];
        derY += TD[i]*aY[i];
        derZ += TD[i]*aZ[i];
    }

    deriv[0] = derX;
    deriv[1] = derY;
    deriv[2] = derZ;
}


// given  global t, returns the point in the curve
void Translacao::getGlobalCatmullRomPoint(float gt, float *pos, float *deriv) {

	int numeroPontos = pontos.size();

	float t = gt * numeroPontos; // this is the real global t
	int index = floor(t);  // which segment
	t = t - index; // where within  the segment

	// indices store the points
	int indices[4]; 
	indices[0] = (index + numeroPontos-1)%numeroPontos;	
	indices[1] = (indices[0]+1)%numeroPontos;
	indices[2] = (indices[1]+1)%numeroPontos; 
	indices[3] = (indices[2]+1)%numeroPontos;

	getCatmullRomPoint(t, indices, pos, deriv);
}

vector<Ponto*> Translacao::getCurva(){

	if(curva.size()==0){
		float res[3];
		float deriv[3];
		for (float t = 0; t<1; t += 0.01){
				getGlobalCatmullRomPoint(t, res, deriv);

				Ponto* p = new Ponto(res[0], res[1], res[2]);
				curva.push_back(p);

		}
	}

	return curva;
}

void Translacao::renderCatmullRomCurve() {

// desenhar a curva usando segmentos de reta - GL_LINE_LOOP
    if(curva.size()==0){
    	getCurva();
    }


    glBegin(GL_LINE_LOOP);
    for(int i = 0; i < curva.size(); i++){
    	Ponto* p = curva.at(i);
        glVertex3f(p->getX(),p->getY(),p->getZ());
    }
    glEnd();
}


void Translacao::rodaElemento(float *deriv){

	float rotacao[4][4];
    float vZ[3];
    normalize(deriv);
    cross(deriv,upY,vZ);
    normalize(vZ);
    cross(vZ,deriv,upY);
    normalize(upY);

    buildRotMatrix(deriv,upY,vZ,*rotacao);

    glMultMatrixf(*rotacao);
}

void Translacao::aplicaOperacao(){
	if(tempo==0){
		glTranslatef(getX(),getY(),getZ());
	}
	else{
		float tempoDecorrido = glutGet(GLUT_ELAPSED_TIME);
		float percentagem = (int) tempoDecorrido % (int) (tempo * 1000);
		percentagem = percentagem / (tempo * 1000);

		float pos[3];
		float deriv[3];
		getGlobalCatmullRomPoint(percentagem,pos,deriv);

		glTranslatef(pos[0],pos[1],pos[2]);
	    
	    rodaElemento(deriv);
	    
	}
}


string Translacao::toString(){
	string res= "";
	cout << "Transl:		X: " << getX() << "	Y: " << getY() << "	Z: " << getZ() << endl;

	return res;
}