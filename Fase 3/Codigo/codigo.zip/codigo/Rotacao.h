#ifndef __ROTACAO_H__
#define __ROTACAO_H__

#include "Operacao.h"
#include <GL/glut.h>

using namespace std;

class Rotacao: public Operacao {

private:
    float angulo;
	float tempo;


public:
	Rotacao();
    Rotacao(float,float,float,float,float);

    float getAngulo();

    void setAngulo(float);

	float getTempo();
    void setTempo(float);


    void aplicaOperacao();

    string toString();
};
		

#endif
