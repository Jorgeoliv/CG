#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <math.h>
#include "Ponto.h"
#include "parser.h"
#include "Patch.h"
using namespace std;


Patch* extraiPatch(string filename){

    ifstream inputFileStream(filename);

    int count;

    string line;
    getline(inputFileStream, line);

    count = stoi(line);
    vector<vector<int>> indices;
    for(int i=0; i < count; i++){
        getline(inputFileStream, line);

        stringstream ss(line);
        vector<int> numbers;

        for(int k = 0; k < 16; k++) {
            string aux;
            ss >> aux;

            int j = stoi(aux);
            numbers.push_back(j);
            //cout << "IND: " << j << endl;
        }

        indices.push_back(numbers);
    }

    getline(inputFileStream, line);
    count = stoi(line);

    cout << "Pontos: " << count << endl;    

    vector<Ponto*> pontosControlo;

    for(int i=0; i < count; i++){
        getline(inputFileStream, line);

        stringstream ss(line);
        vector<float> numbers;

        for(int k = 0; k < 3; k++) {
            string aux;
            ss >> aux;

            float j = stof(aux);
            numbers.push_back(j);
        }

        Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
        pontosControlo.push_back(p);

    }

    cout << "Tam: " << pontosControlo.size() << endl;

    Patch* res = new Patch(indices,pontosControlo);
    return res;

}

vector<Ponto*> torus(float raioTubo, float raioMaior, int fatias, int camadas){

    Ponto* p;
    vector<Ponto*> pontos;

    float alpha = 2*M_PI / fatias;
    float beta = 2*M_PI / camadas;

    float x1, x2, x3, x4, y1, y2, z1, z2, y3, y4;

    for(int i = 0; i<fatias; i++){
        for(int j = 0; j<camadas; j++){


            z1 = raioTubo*sin(beta*j);
            z2 = raioTubo*sin(beta*(j+1));

            y1 = (raioMaior + raioTubo*cos(beta*j))*sin(alpha*i);
            y2 = (raioMaior + raioTubo*cos(beta*j))*sin(alpha*(i+1));
            y3 = (raioMaior + raioTubo*cos(beta*(j+1)))*sin(alpha*i);
            y4 = (raioMaior + raioTubo*cos(beta*(j+1)))*sin(alpha*(i+1));

            x1 = (raioMaior + raioTubo*cos(beta*j))*cos(alpha*i);
            x2 = (raioMaior + raioTubo*cos(beta*j))*cos(alpha*(i+1));
            x3 = (raioMaior + raioTubo*cos(beta*(j+1)))*cos(alpha*i);
            x4 = (raioMaior + raioTubo*cos(beta*(j+1)))*cos(alpha*(i+1));

            //glBegin(GL_TRIANGLES);
            p = new Ponto(x1,y1,z1);
            pontos.push_back(p);
                //glVertex3f(x1, y1, z1);
            p = new Ponto(x2,y2,z1);
            pontos.push_back(p);
                //glVertex3f(x2, y2, z1);
            p = new Ponto(x3,y3,z2);
            pontos.push_back(p);
                //glVertex3f(x3, y3, z2);

            p = new Ponto(x3,y3,z2);
            pontos.push_back(p);
                //glVertex3f(x3, y3, z2);
            p = new Ponto(x2,y2,z1);
            pontos.push_back(p);
                //glVertex3f(x2, y2, z1);
            p = new Ponto(x4,y4,z2);
            pontos.push_back(p);
                //glVertex3f(x4, y4, z2);

            //glEnd();

        }
    }

    return pontos;

}


vector<Ponto*> cilindro(float radius, float height, int slices) {

  Ponto* p;
  vector<Ponto*> pontos;

  float alpha = 2*M_PI / slices;
  float pxA, pxD, pzA, pzD;
    for(int i=0; i<slices;i++){

        pxA = radius * sin(alpha*i);
        pxD = radius * sin(alpha*(i+1));
        pzA = radius * cos(alpha*i);
        pzD = radius * cos(alpha*(i+1));

        //glBegin(GL_TRIANGLES);

        p = new Ponto(0,0,0);
        pontos.push_back(p);
            //glVertex3f(0,0,0);
        p = new Ponto(pxD,0,pzD);
        pontos.push_back(p);
            //glVertex3f(pxD, 0, pzD);
        p = new Ponto(pxA,0,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, 0, pzA);

        p = new Ponto(pxD,0,pzD);
        pontos.push_back(p);    
            //glVertex3f(pxD, 0, pzD);
        p = new Ponto(pxD,height,pzD);
        pontos.push_back(p);
            //glVertex3f(pxD, height, pzD);
        p = new Ponto(pxA,0,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, 0, pzA);

        p = new Ponto(pxA,0,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, 0, pzA);
        p = new Ponto(pxD,height,pzD);
        pontos.push_back(p);
            //glVertex3f(pxD, height, pzD);
        p = new Ponto(pxA,height,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, height, pzA);

        p = new Ponto(0,height,0);
        pontos.push_back(p);
            //glVertex3f(0, height, 0);
        p = new Ponto(pxA,height,pzA);
        pontos.push_back(p);
            //glVertex3f(pxA, height, pzA);
        p = new Ponto(pxD,height,pzD);
        pontos.push_back(p);
            //glVertex3f(pxD, height, pzD);

        //glEnd();
    }

    return pontos;

}




vector<Ponto*> caixa(float sideX, float sideY, float sideZ, int divisions) {
    const float deltaX = sideX/divisions;           // comprimento do lado de cada divisão em X
    const float deltaY = sideY/divisions;           // comprimento do lado de cada divisão em Y
    const float deltaZ = sideZ/divisions;           // comprimento do lado de cada divisão em Z
    const float maxX = sideX/2, minX = -maxX;       // valor máximo/mínimo que a variável em X pode tomar
    const float maxY = sideY/2, minY = -maxY;       // valor máximo/mínimo que a variável em Y pode tomar
    const float maxZ = sideZ/2, minZ = -maxZ; 

    Ponto* p;
    vector<Ponto*> pontos;
    
    for(int i=0; i<divisions; i++){

        for(int j=0; j<divisions; j++){

            // base
            p = new Ponto(minX + i*deltaX, minY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, minY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + i*deltaX, minY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + i*deltaX, minY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, minY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, minY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);

            // topo
            p = new Ponto(minX + i*deltaX, maxY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + i*deltaX, maxY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, maxY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + i*deltaX, maxY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, maxY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX + (i+1)*deltaX, maxY, minZ + j*deltaZ);
            pontos.push_back(p);


            // laterais
            p = new Ponto(minX, minY + i*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + i*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + (i+1)*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + i*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + (i+1)*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(minX, minY + (i+1)*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);

            p = new Ponto(maxX, minY + i*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + (i+1)*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + (i+1)*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + i*deltaY, minZ + j*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + (i+1)*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);
            p = new Ponto(maxX, minY + i*deltaY, minZ + (j+1)*deltaZ);
            pontos.push_back(p);

            p = new Ponto(minX + j*deltaX, minY + i*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + j*deltaX, minY + (i+1)*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + (i+1)*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + j*deltaX, minY + i*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + (i+1)*deltaY, minZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + i*deltaY, minZ);
            pontos.push_back(p);

            p = new Ponto(minX + j*deltaX, minY + i*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + i*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + (i+1)*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + j*deltaX, minY + i*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + (j+1)*deltaX, minY + (i+1)*deltaY, maxZ);
            pontos.push_back(p);
            p = new Ponto(minX + j*deltaX, minY + (i+1)*deltaY, maxZ);
            pontos.push_back(p);
        }
    }
    return pontos;
}


vector<Ponto*> cone(float raio, float altura, int slices,int camadas){

    float angulo = ((2*M_PI)/slices);
    float xA,zA,xP,zP;

    Ponto* p;
    vector<Ponto*> pontos;

    float alturaIntermedia = altura / camadas;
    
    for (int i=0; i < slices;i++) {


        xA = raio * sin(i*angulo);
        zA = raio * cos(i*angulo);


        xP = raio * sin((i+1)*angulo);
        zP = raio * cos((i+1)*angulo);

        

        p = new Ponto(0.0f, 0.0f, 0.0f);
        pontos.push_back(p);
        p = new Ponto(xP, 0.0f, zP);
        pontos.push_back(p);
        p = new Ponto(xA, 0.0f, zA);
        pontos.push_back(p);

        for(int j=0; j < camadas; j++){

            float yA = j*alturaIntermedia;
            float yCima = (j+1)*alturaIntermedia;

            float raioIntermedioCima = raio * ((altura-yCima) /altura);
            float raioIntermedioBaixo = raio * ((altura-yA) /altura);

            xA = raioIntermedioBaixo * sin(i*angulo);
            zA = raioIntermedioBaixo * cos(i*angulo);


            xP = raioIntermedioBaixo * sin((i+1)*angulo);
            zP = raioIntermedioBaixo * cos((i+1)*angulo);

            float xACima = raioIntermedioCima * sin(i*angulo);
            float zACima = raioIntermedioCima * cos(i*angulo);

            float xPCima = raioIntermedioCima * sin((i+1)*angulo);
            float zPCima = raioIntermedioCima * cos((i+1)*angulo);

            p = new Ponto(xA,yA,zA);
            pontos.push_back(p);
            p = new Ponto(xP,yA,zP);
            pontos.push_back(p);
            p = new Ponto(xPCima,yCima,zPCima);
            pontos.push_back(p);

            p = new Ponto(xA,yA,zA);
            pontos.push_back(p);
            p = new Ponto(xPCima,yCima,zPCima);
            pontos.push_back(p);
            p = new Ponto(xACima,yCima,zACima);
            pontos.push_back(p);
        }

    }

    return pontos;

}

vector<Ponto*> esfera(float raio, int fatias, int camadas){

    float alpha = (2*M_PI) / (float) fatias, beta = (M_PI) / (float) camadas;
    float x1, y1, z1, x2, y2, z2, x3, z3, x4,z4;

    vector<Ponto*> pontos;

    for(int i = 0; i<fatias; i++){

        for(int j = 0; j<camadas; j++) {

            y1 = raio * cos(beta*j);

            x1 = raio * sin(beta*j) * sin(alpha*i);
            z1 = raio * sin(beta*j) * cos(alpha*i);

            x2 = raio * sin(beta*j) * sin(alpha * (i+1));
            z2 = raio * sin(beta*j) * cos(alpha * (i+1));

            y2 = raio * cos(beta * (j+1));

            x3 = raio * sin(beta * (j+1)) * sin(alpha*i);
            z3 = raio * sin(beta * (j+1)) * cos(alpha*i);

            x4 = raio * sin(beta * (j+1)) * sin(alpha * (i+1));
            z4 = raio * sin(beta * (j+1)) * cos(alpha * (i+1));

            Ponto *p = new Ponto(x4, y2, z4);
            pontos.push_back(p);

            p = new Ponto(x2, y1, z2);
            pontos.push_back(p);

            p = new Ponto(x1, y1, z1);
            pontos.push_back(p);

            p = new Ponto(x4, y2, z4);
            pontos.push_back(p);

            p = new Ponto(x1, y1, z1);
            pontos.push_back(p);

            p = new Ponto(x3, y2, z3);
            pontos.push_back(p);

        }

    }

    return pontos;

}

vector<Ponto*> plane(float lado){

  float coord = lado/2.0f;
  vector<Ponto*> pontos;
    //Plane
    
    Ponto *p = new Ponto(-coord, 0.0f, coord);
    pontos.push_back(p);
    p = new Ponto(coord, 0.0f, -coord);
    pontos.push_back(p);
    p = new Ponto(-coord, 0.0f, -coord);
    pontos.push_back(p);
    p = new Ponto(-coord, 0.0f, coord);
    pontos.push_back(p);
    p = new Ponto(coord, 0.0f, coord);
    pontos.push_back(p);
    p = new Ponto(coord, 0.0f, -coord);
    pontos.push_back(p);
    return pontos;
}


Ponto* calculaBezierCurve(float t, Ponto* p1, Ponto* p2, Ponto* p3, Ponto* p4) {

    // the t value inverted
    float it = 1.0f-t;

    // calculate blending functions
    float b0 = t*t*t;
    float b1 = 3*t*t*it;
    float b2 = 3*t*it*it;
    float b3 =  it*it*it;

    // sum the effects of the pontos and their respective blending functions
    float x = b0*p1->getX() + b1*p2->getX() + b2*p3->getX() + b3*p4->getX() ;
    float y = b0*p1->getY() + b1*p2->getY() + b2*p3->getY() + b3*p4->getY() ;
    float z = b0*p1->getZ() + b1*p2->getZ() + b2*p3->getZ() + b3*p4->getZ() ;

    return new Ponto(x,y,z);
}

Ponto* calculaPatch(float u,float v, vector<Ponto*> pts_ctrl) {

    Ponto* temp[4];

    temp[0] = calculaBezierCurve(u,pts_ctrl[0],pts_ctrl[1],pts_ctrl[2],pts_ctrl[3]);
    temp[1] = calculaBezierCurve(u,pts_ctrl[4],pts_ctrl[5],pts_ctrl[6],pts_ctrl[7]);
    temp[2] = calculaBezierCurve(u,pts_ctrl[8],pts_ctrl[9],pts_ctrl[10],pts_ctrl[11]);
    temp[3] = calculaBezierCurve(u,pts_ctrl[12],pts_ctrl[13],pts_ctrl[14],pts_ctrl[15]);

    return calculaBezierCurve(v,temp[0],temp[1],temp[2],temp[3]);
}

vector<Ponto*> teapot(int divs, Patch* p){

    vector<Ponto*> pontosTeapot;

    vector<vector<int>> indices = p->getIndices();
    vector<Ponto*> pontos = p->getPontos();

    for(int ind=0; ind < (int) indices.size(); ind++) {

        // Gerar pontos de controlo para o patch "ind"
        vector<Ponto*> pontos_controlo;
        for(int pc=0; pc<16; pc++){
            pontos_controlo.push_back(pontos[indices[ind][pc]]);
        }

        // use the parametric time value 0 to 1
        for (int i = 0; i < divs; ++i) {

            // calculate the parametric u value
            float u1 = (float) i / (divs - 1);
            float u2 = (float) (i + 1) / (divs - 1);

            for (int j = 0; j < divs; ++j) {

                // calculate the parametric v values
                float v1 = (float) j / (divs - 1);
                float v2 = (float) (j+1) / (divs - 1);

                // calculate the points on the surface
                Ponto* p1 = calculaPatch(u1, v1, pontos_controlo);
                Ponto* p2 = calculaPatch(u1, v2, pontos_controlo);
                Ponto* p3 = calculaPatch(u2, v1, pontos_controlo);
                Ponto* p4 = calculaPatch(u2, v2, pontos_controlo);

                pontosTeapot.push_back(p1);
                pontosTeapot.push_back(p3);
                pontosTeapot.push_back(p4);
                pontosTeapot.push_back(p1);
                pontosTeapot.push_back(p4);
                pontosTeapot.push_back(p2);
            }
        }
    }
    return pontosTeapot;
}


int comparaFigura(string a){

  if(a.compare("plane")==0) return 1;
  if(a.compare("box")==0) return 2;
  if(a.compare("cone")==0) return 3;
  if(a.compare("sphere")==0) return 4;
  if(a.compare("cylinder")==0) return 5;
  if(a.compare("torus")==0) return 6;
  if(a.compare("teapot")==0) return 7;

  return 0;
}

int main (int argc, char** argv) {
  ofstream myfile;
  vector<Ponto*> pontos;
  char* nome_ficheiro;

  int aux = comparaFigura(argv[1]);
  switch(aux){
    case 1: {
      nome_ficheiro = argv[3];
      string tam(argv[2]);
      float lado = stof(tam);
      
      if(!(lado > 0)){
          printf("Erro, valor inválido do lado!\n");
          return 1;
        }

      pontos = plane(lado);
      break;
    }

    case 2: {
      nome_ficheiro = argv[6];

      string aux1(argv[2]);
      float ladoX = stof(aux1);

      if(!(ladoX > 0)){
          printf("Erro, valor inválido do lado X!\n");
          return 1;
      }

      string aux2(argv[3]);
      float ladoY = stof(aux2);

      if(!(ladoY > 0)){
          printf("Erro, valor inválido do lado Y!\n");
          return 1;
      }

      string aux3(argv[4]);
      float ladoZ = stof(aux3);

      if(!(ladoZ > 0)){
          printf("Erro, valor inválido do lado Z!\n");
          return 1;
      }

      string aux4(argv[5]);
      int divisoes = stoi(aux4);

      if(!(divisoes > 0)){
          printf("Erro, valor inválido das divisões!\n");
          return 1;
      }

      pontos = caixa(ladoX, ladoY, ladoZ, divisoes);
      break;
    }


    case 3: {
      nome_ficheiro = argv[6];
      string aux(argv[2]);
      float raio = stof(aux);

      if(!(raio > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string aux2(argv[3]);
      float altura = stof(aux2);

      if(!(altura > 0)){
          printf("Erro, valor inválido da altura!\n");
          return 1;
      }

      string aux3(argv[4]);
      int fatias = stoi(aux3);

      if(!(fatias > 0)){
          printf("Erro, valor inválido das fatias!\n");
          return 1;
      }

      string aux4(argv[5]);
      int camadas = stoi(aux4);

      if(!(camadas > 0)){
          printf("Erro, valor inválido das camadas!\n");
          return 1;
      }

      pontos = cone(raio,altura,fatias,camadas);
      break;
    }


    case 4:{
      nome_ficheiro = argv[5];

      string raio(argv[2]);
      float r = stof(raio); 

      if(!(r > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string fatias(argv[3]);
      int f = stoi(fatias);
  
      if(!(f > 0)){
          printf("Erro, valor inválido das fatias!\n");
          return 1;
      }

      string camadas(argv[4]);
      int c = stoi(camadas);


      if(!(r > 0)){
          printf("Erro, valor inválido das camadas!\n");
          return 1;
      }

      pontos = esfera(r, f, c);
      break;
    }

    case 5: {
      nome_ficheiro = argv[5];
      string aux(argv[2]);
      float raio = stof(aux);

      if(!(raio > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string aux2(argv[3]);
      float altura = stof(aux2);

      if(!(altura > 0)){
          printf("Erro, valor inválido da altura!\n");
          return 1;
      }

      string aux3(argv[4]);
      int fatias = stoi(aux3);

      if(!(fatias > 0)){
          printf("Erro, valor inválido das fatias!\n");
          return 1;
      }

      pontos = cilindro(raio,altura,fatias);
      break;
    }

    case 6: {
      nome_ficheiro = argv[6];
      string aux(argv[2]);
      float raioTubo = stof(aux);

      if(!(raioTubo > 0)){
          printf("Erro, valor inválido do raio!\n");
          return 1;
      }

      string aux2(argv[3]);
      float raioAnel = stof(aux2);

      if(!(raioAnel > 0)){
          printf("Erro, valor inválido da altura!\n");
          return 1;
      }

      string aux3(argv[4]);
      int fatias = stoi(aux3);

      if(!(fatias > 0)){
          printf("Erro, valor inválido das fatias!\n");
          return 1;
      }

      string aux4(argv[5]);
      int camadas = stoi(aux4);

      if(!(camadas > 0)){
          printf("Erro, valor inválido das camadas!\n");
          return 1;
      }

      pontos = torus(raioTubo,raioAnel,fatias,camadas);
      break;
    }

    case 7: {
      nome_ficheiro = argv[4];
      string aux(argv[2]);
      float divisoes = stoi(aux);

      if(!(divisoes > 3)){
        printf("Erro, valor inválido de divisões!\n");
        return 1;
      }

      string input(argv[3]);
      Patch* p = extraiPatch(input);

      pontos = teapot(divisoes, p);
      break;
    }

    default: printf("Opção inválida!");return 1; 
  }
  
  myfile.open(nome_ficheiro);

  myfile << pontos.size() << endl;
  for(Ponto* p: pontos){
    
    string escreve = p->toString();
    myfile << escreve << endl;
  }

  
  myfile.close();

  return 0;
}
