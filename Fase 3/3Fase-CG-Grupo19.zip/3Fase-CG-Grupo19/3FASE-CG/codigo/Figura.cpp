#include "Figura.h"
#include <iostream>

using namespace std;


Figura::Figura() {
}



Figura::Figura(vector<Ponto*> ps) {
	this->adicionaPontos(ps);
}


void Figura::adicionaPontos(vector<Ponto*> ps){
	numeroPontos = ps.size();
	float* vertices = (float*) malloc(sizeof(float) * ps.size() * 3);

	int i = 0;
	for(Ponto* p: ps){
		vertices[i++] = p->getX();
		vertices[i++] = p->getY();
		vertices[i++] = p->getZ();
	}

    cout << numeroPontos << endl;

	glGenBuffers(1, pontos);
	glBindBuffer(GL_ARRAY_BUFFER, pontos[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * numeroPontos * 3, vertices, GL_STATIC_DRAW);

	free(vertices);
}

GLuint Figura::getPontos(){
	return pontos[0];
}

void Figura::desenha(){

    cout << "Desenhar" << endl;

	glBindBuffer(GL_ARRAY_BUFFER, pontos[0]);
	glVertexPointer(3, GL_FLOAT, 0, 0);
    glDrawArrays(GL_TRIANGLES, 0, numeroPontos * 3);
}

string Figura::toString(){
	string res="";

	/*for(Ponto* p: pontos){
		res+= " { " + p->toString() + " } ";
	}*/
	return res;
}
