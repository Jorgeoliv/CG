#ifndef __Ponto_H__
#define __Ponto_H__

#include <GL/glew.h>
#include <math.h>
#include <string>
#include <vector>

#include "Ponto.h"
#include <GL/glut.h>
#include <IL/il.h>

using namespace std;

class Figura {



    GLuint pontos[1];
    int numeroPontos;
private:

    void adicionaPontos(vector<Ponto*>);

public:
    Figura();
    Figura(vector<Ponto*>);

    GLuint getPontos();

    void desenha();


    string toString();
};
		

#endif
