#include "Operacao.h"
#include <iostream>

using namespace std;


Operacao::Operacao() {
}

Operacao::Operacao(float a, float b, float c){
	x=a;
	y=b;
	z=c;
}

float Operacao::getX(){
	return x;
}


float Operacao::getY(){
	return y;
}


float Operacao::getZ(){
	return z;
}

void Operacao::setX(float a){
	x=a;
}
 

void Operacao::setY(float a){
	y=a;
}


void Operacao::setZ(float a){
	z=a;
}

/*
string Operacao::toString(){
	string res="";

	return res;
}
*/