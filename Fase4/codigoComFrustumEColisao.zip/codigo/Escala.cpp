#include "Escala.h"
#include <iostream>

using namespace std;


Escala::Escala() : Operacao() {
}


Escala::Escala(float x, float y, float z)
      : Operacao(x, y, z) { }


void Escala::aplicaOperacao(glm::mat4* matriz){
	glScalef(getX(),getY(),getZ());
	(*matriz) = glm::scale(*matriz,glm::vec3(getX(),getY(),getZ()));
}



string Escala::toString(){
	string res= "";
	cout << "Escala:		X: " << getX() << "	Y: " << getY() << "	Z: " << getZ() << endl;

	return res;
}