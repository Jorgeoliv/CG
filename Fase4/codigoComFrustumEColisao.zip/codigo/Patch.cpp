//
// Created by jose on 03-03-2018.
//

#include "Patch.h"


Patch::Patch(){
}

Patch::Patch(vector<vector<int>> i, vector<Ponto*> pc){
    indices = i;
    pontos = pc;
}

Patch::Patch(Patch &p){
    indices = p.getIndices();
    pontos = p.getPontos();
}

vector<vector<int>> Patch::getIndices(){
	return indices;
}


vector<Ponto*> Patch::getPontos(){
	return pontos;
}

string Patch::toString(){
    string res = "";
    return res;
}