#ifndef __LuzPontual_H__
#define __LuzPontual_H__

#include <GL/glew.h>
#include <math.h>
#include <string>
#include <vector>

#include "Ponto.h"
#include "Luz.h"
#include <GL/glut.h>
#include <IL/il.h>

using namespace std;

class LuzPontual : public Luz {
	
private:
	
	float atenuacao;

public:
	LuzPontual();
	
	LuzPontual(float[4],int,float);
    	
	void desenhaLuz();

};
		

#endif
