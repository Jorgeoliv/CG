#include "LuzFoco.h"

LuzFoco::LuzFoco() : Luz(){}

LuzFoco::LuzFoco(float p[4],int nr,float a,float dir[3],float at, float exp) : Luz(nr,p){
	angulo = a;

	atenuacao = at;
	expoente = exp;

	for(int i=0; i<3;i++){
		direcao[i] = dir[i];
	}
}

void LuzFoco::desenhaLuz(){


	int luzA = this->getNumero();

	if(luzA>7){
		luzA = 7;
	}


	// posicao
	glLightfv(GL_LIGHT0 +luzA, GL_POSITION, this->getPosicao());
	
	// cores
	glLightfv(GL_LIGHT0 +luzA, GL_AMBIENT, this->getAmbiente());
	glLightfv(GL_LIGHT0 +luzA, GL_DIFFUSE, this->getDifusa());
	glLightfv(GL_LIGHT0 +luzA, GL_DIFFUSE, this->getEspecular());

	//da spot
	glLightfv(GL_LIGHT0 +luzA, GL_SPOT_DIRECTION, direcao);
	glLightf(GL_LIGHT0 +luzA, GL_SPOT_CUTOFF, angulo);
	glLightf(GL_LIGHT0 +luzA,GL_SPOT_EXPONENT, expoente);

	//atenuacao
	glLightf(GL_LIGHT0 +luzA,GL_LINEAR_ATTENUATION,atenuacao);

}
