#include "Luz.h"



Luz::Luz(){}

Luz::Luz(int nr, float pos[4]) {

    if(nr == 0){
        for(int i = 0; i < 3; i++){
            difusa[i] = 1;
            especular[i] = 1;
        }
    }

    numero = (nr > 7 ? 7 : nr);

    for(int i = 0 ; i < 4; i++){
        posicao[i] = pos[i];
    }

}



GLfloat* Luz::getPosicao(){

	return this->posicao;
}

GLfloat* Luz::getAmbiente(){

	return this->ambiente;
}

GLfloat* Luz::getDifusa(){

	return this->difusa;
}

GLfloat* Luz::getEspecular(){

	return this->especular;
}

int Luz::getNumero(){
    return numero;
}
