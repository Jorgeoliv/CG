#ifndef __ESCALA_H__
#define __ESCALA_H__

#include "Operacao.h"
#include <GL/glut.h>

using namespace std;

class Escala: public Operacao {

private:
    

public:
	Escala();
    Escala(float,float,float);

    void aplicaOperacao(glm::mat4*);

	void alteraMatriz(glm::mat4* matriz);

    string toString();
};
		

#endif
