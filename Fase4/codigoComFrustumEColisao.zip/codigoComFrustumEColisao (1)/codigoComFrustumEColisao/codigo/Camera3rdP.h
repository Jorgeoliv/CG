#ifndef ENGINE_CAMERA3RDP_H
#define ENGINE_CAMERA3RDP_H

#include <string>
#include "Ponto.h"
#include <math.h>
#include "FrustumG.h"
#include <GL/glut.h>

class Camera3rdP{



    float alpha;
    float beta;
    float raio;
    int mouseX;
    int mouseY;
    int mouseTracking;
    Ponto* posicao;
    Ponto* foco;
    Vec3 camVecX;
    Vec3 camVecY;
    Vec3 camVecZ;
    float angulo;
    float velocidade;
    FrustumG* frustum;

    float mX;
    float mY;
    float mZ;


public:
    Camera3rdP();
    Camera3rdP(float,float,float);
    Camera3rdP(float,float,float,float,float);
    void alteraFocoCamera(float,float,float);
    void alteraVetoresCamera();
    void alteraPosicaoCamera();
    void mouseButtons(int button, int state, int xx, int yy);
    bool mouseMotion(int xx, int yy);
    bool normalKeys(unsigned char c, int xx, int yy);
    void specialKeys(int key, int xx, int yy);
    Ponto* getPosicao();
    Ponto* getFoco();
    float getAlpha();
    float getBeta();
    void setFrustumDef();
    void setFrustumInternals(float,float,float,float);
    void setFoco(Ponto*);
    void voltaAtras();

    Plane* getFrustumPlanos();
};
#endif

