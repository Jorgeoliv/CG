#ifndef __Ponto_H__
#define __Ponto_H__

#include <GL/glew.h>
#include <math.h>
#include <string>
#include <vector>

#include "Ponto.h"
#include "Material.h"
#include "ViewFrustumeColisao.h"
#include <GL/glut.h>
#include <IL/il.h>
#include "glm/glm.hpp"


using namespace std;

class Figura {



    GLuint pontos[1];
    int numeroPontos;
    GLuint normais[1];
    int numeroNormais;
    GLuint texturas[1];
    int numeroTexturas;
    int idTextura;
    Material* cor;
    ViewFrustumeColisao * teste;

private:

    void adicionaPontos(vector<Ponto*>,vector<Ponto*>,vector<Ponto*>);

public:
    Figura();
    Figura(vector<Ponto*>,vector<Ponto*>,vector<Ponto*>,int,Material*,ViewFrustumeColisao*);

    GLuint getPontos();

    bool desenha(Plane[6],glm::mat4);

    bool possoMover(float posX, float posY, float posZ, float r, glm::mat4 matriz);


    string toString();
};
		

#endif
