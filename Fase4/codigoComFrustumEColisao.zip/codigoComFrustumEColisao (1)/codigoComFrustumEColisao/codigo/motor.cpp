
#include "parser.h"
#include "Camera1stP.h"
#include "Camera3rdP.h"
#include <stack>
#include "glm/glm.hpp"


#define _USE_MATH_DEFINES
#include <math.h>

using namespace std;

//using namespace glm;


Camera1stP* camera1stP;
Camera3rdP* camera3rdP;

Grupo* cena;

int numeroDesenhos;
int numeroObejtos;
float direcaoHorizontal=0;
float direcaoVertical=0;
bool thirdPerson = false;

stack<glm::mat4> stackMatrizes;
glm::mat4 matrizAtual;



bool possoMover(Grupo * g){

    bool res = true;
    glm::mat4 aux = glm::mat4(matrizAtual);
    stackMatrizes.push(aux);

    vector<Operacao*> operacoes = g->getOperacoes();
    for(Operacao* op: operacoes){
        //  cout << "Operacao" << endl;
        op->alteraMatriz(&matrizAtual);
    }


    vector<Figura*> figuras = g->getFiguras();
    for(Figura* fig: figuras){
        Ponto * aux;
        if (thirdPerson) aux = camera3rdP->getFoco();
        else aux = camera1stP->getPosicao();

        if(res){
            //cout << "Vou ver figura" << endl;
            res = fig->possoMover(aux->getX(),aux->getY(),aux->getZ(),2,matrizAtual);
            if(!res){
              //  cout << "N vou poder mover" << endl;
            }
        }
    }

    if(res) {
        vector<Grupo *> gruposFilhos = g->getGrupos();

        for (Grupo *filho: gruposFilhos) {
            if(res){
                //cout << "Vou ver filho" << endl;
                res = possoMover(filho);
            }
        }
    }

    matrizAtual = stackMatrizes.top();
    stackMatrizes.pop();


    //cout << "Vou retornar " << res << endl;
    return res;
}

void changeSize(int w, int h) {

    // Prevent a divide by zero, when window is too short
    // (you cant make a window with zero width).
    if(h == 0)
        h = 1;

    // compute window's aspect ratio
    float ratio = w * 1.0 / h;

    // Set the projection matrix as current
    glMatrixMode(GL_PROJECTION);
    // Load Identity Matrix
    glLoadIdentity();

    // Set the viewport to be the entire window
    glViewport(0, 0, w, h);

    // Set perspective
    gluPerspective(45.0f ,ratio, 1.0f ,1000.0f);

    camera1stP->setFrustumInternals(45.0f,ratio,1.0f,1000.0f);
    camera3rdP->setFrustumInternals(45.0f,ratio,1.0f,1000.0f);
    // return to the model view matrix mode
    glMatrixMode(GL_MODELVIEW);
}


void imprimeFigura(vector<Figura*> figuras){


    glColor3f(0.3,0.3,0.8);
    //glBegin(GL_TRIANGLES);

    //cout << "Imprimindo figura" << endl;
    Plane* planos;
    if (thirdPerson) planos = camera3rdP->getFrustumPlanos();
    else planos = camera1stP->getFrustumPlanos();

    for(Figura* f: figuras){

        if(f->desenha(planos,matrizAtual)){
            numeroDesenhos++;
        }
        numeroObejtos++;

    }

    glColor3f(0.9,0.9,0.9);

    glEnd();


}

void imprimeGrupo(Grupo* g){

    //cout << "Vou imprimir grupo" << endl;
    //if(g->getID() < 6 && g->getID()!=0) return;

    vector<Luz*> luzes = g->getLuzes();

    for(Luz* l: luzes){
        l->desenhaLuz();
    }

    glPushMatrix();
    glm::mat4 aux = glm::mat4(matrizAtual);
    stackMatrizes.push(aux);

    vector<Operacao*> operacoes = g->getOperacoes();
    for(Operacao* op: operacoes){
      //  cout << "Operacao" << endl;
        op->aplicaOperacao(&matrizAtual);
    }


    vector<Figura*> figuras = g->getFiguras();
    imprimeFigura(figuras);

    vector<Grupo*> gruposFilhos = g->getGrupos();
    for(Grupo* filho: gruposFilhos){
        imprimeGrupo(filho);
    }

    glPopMatrix();
    matrizAtual = stackMatrizes.top();
    stackMatrizes.pop();

}

void percorreGrupos(){

    for(int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++){
            //cout << matrizAtual[j][i] << "\t";
        }

        //cout << endl;
    }

    imprimeGrupo(cena);
    
}


void desenhaFoguetao(){

    Ponto* foco = camera3rdP->getFoco();
    glPushMatrix();
    glTranslatef(foco->getX(),foco->getY(),foco->getZ());
    glRotatef(direcaoHorizontal,0,-1,0);
    glRotatef(direcaoVertical,1,0,0);
    glColor3f(0.9,0.9,0.9);
    glutSolidCone(0.05, 0.15, 100, 100);
    glPopMatrix();
}


void renderScene(void) {

    // clear buffers

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);

    glLoadIdentity();

    // set the camera
    Ponto *pos, *foco;

    numeroDesenhos = 0;
    numeroObejtos = 0;

    if(thirdPerson)
    {
        pos = camera3rdP->getPosicao();
        foco = camera3rdP->getFoco();

        gluLookAt(pos->getX(),pos->getY()+0.6,pos->getZ(),
                  foco->getX(),foco->getY()+0.6,foco->getZ(),
                  0.0f,1.0f,0.0f);

        desenhaFoguetao();
        camera3rdP->setFrustumDef();
    }
    else
    {
        pos = camera1stP->getPosicao();
        foco = camera1stP->getFoco();

        gluLookAt(pos->getX(),pos->getY(),pos->getZ(),
                  foco->getX(),foco->getY(),foco->getZ(),
                  0.0f,1.0f,0.0f);

        camera1stP->setFrustumDef();
    }

    glCullFace(GL_BACK);
    percorreGrupos();

  //  cout << "Total: " << numeroObejtos << endl;
   // cout << "Desenhados: " << numeroDesenhos << endl;
    // End of frame
    glutSwapBuffers();
}


void processKeysAux(unsigned char c, int xx, int yy){
    Ponto* p2 = camera1stP->getPosicao();
    bool e1 = camera1stP->normalKeys(c, xx, yy);
    bool e2 = camera3rdP->normalKeys(c, xx, yy);
    if((e1 && !thirdPerson) || (e2 && thirdPerson)){

        if(!possoMover(cena)){
            cout << "Não posso mover" << endl;
            //Ponto* p = camera1stP->getPosicao();
            camera1stP->voltaAtras();
            camera3rdP->voltaAtras();
            //Ponto* p1 = camera->getPosicao();

            //cout << "Antes: X: " << p->getX() << "! Y: " << p->getY() << "! Z: " << p->getZ() << endl;
            //cout << "Depois: X: " << p1->getX() << "! Y: " << p1->getY() << "! Z: " << p1->getZ() << endl;
        }
    }
}


void processKeys(unsigned char c, int xx, int yy) {
    Ponto* pos;
    float a, b;

    switch(c){

        case('1'): //visualizacao em 1ª pessoa
            if (thirdPerson) {
                thirdPerson = false;
                pos = camera3rdP->getFoco();
                a = camera3rdP->getAlpha() + 180;
                b = camera3rdP->getBeta();
                camera1stP = new Camera1stP(pos->getX(), pos->getY(), pos->getZ(), a, b);
            }
            break;

        case('3'): //visualizacao em 3ª pessoa
            if (!thirdPerson) {
                thirdPerson = true;
                pos = camera1stP->getPosicao();
                a = camera1stP->getAlpha() + 180;
                b = camera1stP->getBeta();
                camera3rdP = new Camera3rdP(pos->getX(), pos->getY(), pos->getZ(), a, b);
            }
            break;

        case('t'): //visualizacao total
            glPolygonMode(GL_FRONT, GL_FILL);
            break;

        case('l'): //visualizacao por linhas
            glPolygonMode(GL_FRONT, GL_LINE);
            break;

        case 'w':
            processKeysAux(c, xx, yy);
            direcaoVertical = camera3rdP->getBeta();
            direcaoHorizontal = camera3rdP->getAlpha() + 180;
            break;

        case 's':
            processKeysAux(c, xx, yy);
            direcaoVertical = -camera3rdP->getBeta();
            direcaoHorizontal = camera3rdP->getAlpha();
            break;

        case 'a':
            processKeysAux(c, xx, yy);
            direcaoVertical = 0;
            direcaoHorizontal = camera3rdP->getAlpha() + 90;
            break;

        case 'd':
            processKeysAux(c, xx, yy);
            direcaoVertical = 0;
            direcaoHorizontal = camera3rdP->getAlpha() + 270;
            break;

        case 'c':
            processKeysAux(c, xx, yy);
            direcaoVertical = -90;
            direcaoHorizontal = 0;
            break;

        case 'b':
            processKeysAux(c, xx, yy);
            direcaoVertical = 90;
            direcaoHorizontal = 0;
            break;

        default:
            processKeysAux(c, xx, yy);
            break;
    }
}


void processSpecialKeys(int key, int xx, int yy) {

    camera1stP->specialKeys(key, xx, yy);
    camera3rdP->specialKeys(key, xx, yy);
}


void processMouseButtons(int button, int state, int xx, int yy) {

    camera1stP->mouseButtons(button, state, xx, yy);
    camera3rdP->mouseButtons(button, state, xx, yy);
}


void processMouseMotion(int xx, int yy) {

    Ponto* p = camera1stP->getPosicao();
    bool e1 = camera1stP->mouseMotion(xx, yy);
    bool e2 = camera3rdP->mouseMotion(xx, yy);
    if((e1 && !thirdPerson) || (e2 && thirdPerson)){

        cout << "Não posso mover" << endl;

        if(!possoMover(cena)){
            camera1stP->voltaAtras();
            camera3rdP->voltaAtras();
        }
    }

}


void initGL(){
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);

    //converte();
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glClearColor(0, 0, 0, 0);

    glEnable(GL_LIGHTING);
    for(int i = 0; i < 7; i++){
        glEnable(GL_LIGHT0+i);
    }

    glEnable(GL_TEXTURE_2D);
}


int main(int argc, char **argv) {

    if(argc < 2){
        cout << "ERRO! Poucos argumentos." << endl;
        return 0;

    }

    camera1stP = new Camera1stP(7.0, 7.0, 7.0);
    camera3rdP = new Camera3rdP(7.0, 7.0, 7.0);

    glutInit(&argc, argv);
    ilInit();
    glutInitDisplayMode(GLUT_DEPTH|GLUT_DOUBLE|GLUT_RGBA);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(800,800);
    glutCreateWindow("CG-TP@DI-UM");

    GLenum err = glewInit();
    if(GLEW_OK != err){
        printf("ERRO NO GLEW!Mensagem: %s\n", glewGetErrorString(err));
        return 0;
    }

    cena = (parseFile(argv[1]));

    //glm::mat4 matrizInicial = glm::mat4(1.0f);
    //matrizAtual = matrizInicial;

    cout << "Fim parse xml" << endl;
    if((cena) == nullptr){
        printf("Erro no parsing!\n");
        return 1;
    }


// Required callback registry

    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutReshapeFunc(changeSize);

// Callback registration for keyboard processing
    glutKeyboardFunc(processKeys);
    glutSpecialFunc(processSpecialKeys);
    glutMouseFunc(processMouseButtons);
    glutMotionFunc(processMouseMotion);

//  OpenGL settings
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glEnableClientState(GL_VERTEX_ARRAY);

    initGL();

// enter GLUT's main cycle
    glutMainLoop();



    return 1;
}
