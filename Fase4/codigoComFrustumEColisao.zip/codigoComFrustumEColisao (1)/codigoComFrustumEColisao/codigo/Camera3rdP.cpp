#include "Camera3rdP.h"


Camera3rdP::Camera3rdP(float x, float y, float z){

    posicao = new Ponto();
    foco = new Ponto(x,y,z);
    camVecX;
    camVecY;
    camVecZ;
    alpha = 0;
    beta  = 0;
    raio = 2;
    mouseX = -1;
    mouseY = -1;
    mouseTracking = 0;
    angulo = 0.5;
    velocidade = 0.1;
    frustum = new FrustumG();
    mX = 0;
    mY = 0;
    mZ = 0;
    mA = alpha;
    mB = beta;
    mR = raio;
    alteraPosicaoCamera();

}


Camera3rdP::Camera3rdP(float x, float y, float z, float a, float b){

    posicao = new Ponto();
    foco = new Ponto(x,y,z);
    camVecX;
    camVecY;
    camVecZ;
    alpha = a;
    beta  = b;
    raio = 2;
    mouseX = -1;
    mouseY = -1;
    mouseTracking = 0;
    angulo = 0.5;
    velocidade = 0.1;
    frustum = new FrustumG();
    mX = 0;
    mY = 0;
    mZ = 0;
    mA = alpha;
    mB = beta;
    mR = raio;
    alteraPosicaoCamera();


}


Ponto* Camera3rdP::getPosicao() {

    return posicao;
}


Ponto* Camera3rdP::getFoco() {

    return foco;
}

float Camera3rdP::getAlpha() {

    return alpha;
}


float Camera3rdP::getBeta() {

    return beta;
}


void Camera3rdP::alteraVetoresCamera(){

    float dx = foco->getX() - posicao->getX();
    float dy = foco->getY() - posicao->getY();
    float dz = foco->getZ() - posicao->getZ();
    Vec3 d(dx, dy, dz);

    Vec3 upAux(0,1,0);
    camVecZ = d;
    camVecZ.normalize();
    camVecX = upAux*camVecZ;
    camVecX.normalize();
    camVecY = camVecZ*camVecX;
    camVecY.normalize();
}


void Camera3rdP::setFoco(Ponto *p) {
    foco = p;
    alteraPosicaoCamera();
}


void Camera3rdP::alteraPosicaoCamera(){

    float posicaoX = foco->getX() + raio * sin(-alpha * 3.14 / 180.0) * cos(-beta * 3.14 / 180.0);
    float posicaoY = foco->getY() + raio *                              sin(+beta * 3.14 / 180.0);
    float posicaoZ = foco->getZ() + raio * cos(-alpha * 3.14 / 180.0) * cos(-beta * 3.14 / 180.0);
    posicao->set(posicaoX, posicaoY, posicaoZ);

    alteraVetoresCamera();
}


void Camera3rdP::alteraFocoCamera(float x, float y, float z) {

    Vec3 move(foco->getX() , foco->getY() , foco->getZ());
    move = move + (camVecX*x + camVecY*y+ camVecZ*z)*velocidade;

    foco->set(move.x, move.y, move.z);

    alteraPosicaoCamera();
}


void Camera3rdP::mouseButtons(int button, int state, int xx, int yy) {

    if (state == GLUT_DOWN)  {
        mouseX = xx;
        mouseY = yy;
        if (button == GLUT_LEFT_BUTTON)
            mouseTracking = 1;
        else if (button == GLUT_RIGHT_BUTTON)
            mouseTracking = 2;
        else
            mouseTracking = 0;
    }
    else if (state == GLUT_UP)
        mouseTracking = 0;
}


bool Camera3rdP::mouseMotion(int xx, int yy) {

    float deltaX, deltaY;
    mX = 0; mY = 0; mZ = 0;
    mA = alpha;
    mB = beta;
    mR = raio;

    if (!mouseTracking)
        return false;

    deltaX = xx - mouseX;
    deltaY = yy - mouseY;

    mouseX = xx;
    mouseY = yy;

    if (mouseTracking == 1) {

        alpha += deltaX*angulo;
        beta += deltaY*angulo;

        if (beta > 85.0)
            beta = 85.0;
        else if (beta < -85.0)
            beta = -85.0;

        alteraPosicaoCamera();
        return true;
    }

    else if (mouseTracking == 2) {

        raio += deltaY*velocidade;
        if (raio < 2) raio = 2;
        alteraPosicaoCamera();
        return true;
    }
    return false;
}


bool Camera3rdP::normalKeys(unsigned char c, int xx, int yy) {
    Vec3 move;
    bool res = false;

    mX = 0; mY = 0;  mZ = 0;
    mA = alpha;
    mB = beta;
    mR = raio;

    switch (c) {
        case 27:
            exit(0);

        case '+':
            velocidade *= 1.33;
            if(velocidade > 2.0)
                velocidade = 2.0;
            break;

        case '-':
            velocidade *= 0.67;
            if(velocidade < 0.005)
                velocidade = 0.01;
            break;

        case 'w':
            res = true;
            alteraFocoCamera(0,0,+1);
            mZ = -1;
            break;

        case 's':
            res = true;
            alteraFocoCamera(0,0,-1);
            mZ = +1;
            break;

        case 'a':
            res = true;
            alteraFocoCamera(+1,0,0);
            mX = -1;
            break;

        case 'd':
            res = true;
            alteraFocoCamera(-1,0,0);
            mX = +1;
            break;

        case 'c':
            res = true;
            alteraFocoCamera(0,+1,0);
            mY = -1;
            break;

        case 'b':
            res = true;
            alteraFocoCamera(0,-1,0);
            mY = +1;
            break;
    }

    return res;
}


bool Camera3rdP::specialKeys(int key, int xx, int yy) {
    bool res = false;

    mX = 0; mY = 0; mZ = 0;
    mA = alpha;
    mB = beta;
    mR = raio;

    switch (key) {

        case GLUT_KEY_RIGHT:
            res = true;
            alpha -= angulo;
            alteraPosicaoCamera();
            break;

        case GLUT_KEY_LEFT:
            res = true;
            alpha += angulo;
            alteraPosicaoCamera();
            break;

        case GLUT_KEY_UP:
            res = true;
            beta += angulo;
            alteraPosicaoCamera();
            break;

        case GLUT_KEY_DOWN:
            res = true;
            beta -= angulo;
            alteraPosicaoCamera();
            break;

        case GLUT_KEY_PAGE_DOWN:
            angulo *= 0.67;
            if(angulo > 2.0)
                angulo = 2.0;
            break;

        case GLUT_KEY_PAGE_UP:
            angulo *= 1.33;
            if(angulo < 0.005)
                angulo = 0.01;
            break;
    }

    return res;
}


void Camera3rdP::setFrustumDef(){
    Vec3 p(posicao->getX(),posicao->getY()+0.6,posicao->getZ());
    Vec3 l(foco->getX(),foco->getY()+0.6,foco->getZ());
    Vec3 u(0,1,0);
    frustum->setCamDef(p,l,u);
    frustum->drawLines();
}

void Camera3rdP::setFrustumInternals(float a, float b, float c, float d){
    frustum->setCamInternals(a,b,c,d);
}

Plane* Camera3rdP::getFrustumPlanos(){
    return frustum->pl;
}

void Camera3rdP::voltaAtras(){

    alpha = mA;
    beta = mB;
    raio = mR;
    alteraFocoCamera(mX,mY,mZ);
}
