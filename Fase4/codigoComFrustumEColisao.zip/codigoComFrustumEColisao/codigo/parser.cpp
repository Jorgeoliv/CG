#include "parser.h"

using namespace tinyxml2;
using namespace std;

#ifndef XMLCheckResult
	#define XMLCheckResult(a_eResult) if (a_eResult != XML_SUCCESS) { printf("Error: %i\n", a_eResult);}
#endif


int numeroGrupo = 0;
int nrLuz=0;


int loadTexture(std::string s) {

    unsigned int t,tw,th;
    unsigned char *texData;
    unsigned int texID;

    ilInit();
    ilEnable(IL_ORIGIN_SET);
    ilOriginFunc(IL_ORIGIN_LOWER_LEFT);
    ilGenImages(1,&t);
    ilBindImage(t);
    ilLoadImage((ILstring)s.c_str());
    tw = ilGetInteger(IL_IMAGE_WIDTH);
    th = ilGetInteger(IL_IMAGE_HEIGHT);
    ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE);
    texData = ilGetData();

    glGenTextures(1,&texID);

    glBindTexture(GL_TEXTURE_2D,texID);
    glTexParameteri(GL_TEXTURE_2D,	GL_TEXTURE_WRAP_S,		GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,	GL_TEXTURE_WRAP_T,		GL_REPEAT);

    glTexParameteri(GL_TEXTURE_2D,	GL_TEXTURE_MAG_FILTER,   	GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,	GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tw, th, 0, GL_RGBA, GL_UNSIGNED_BYTE, texData);
    glGenerateMipmap(GL_TEXTURE_2D);

    glBindTexture(GL_TEXTURE_2D, 0);

    return texID;

}


Figura* extraiFicheiro(string filename, string textura, Material* m, ViewFrustumeColisao * vf){

	ifstream inputFileStream(filename);

	int count;

	string line;
    getline(inputFileStream, line);

    count = stoi(line);
    vector<Ponto*> pontos;
    vector<Ponto*> normais;
    vector<Ponto*> texturas;

    for(int i=0; i < count; i++){
    	getline(inputFileStream, line);

    	stringstream ss(line);
    	vector<float> numbers;

    	for(int k = 0; k < 3; k++) {
    		string aux;
    		ss >> aux;

    		float j = stof(aux);
        	numbers.push_back(j);
    	}

    	Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
    	pontos.push_back(p);

    }

    getline(inputFileStream, line);

    count = stoi(line);


    for(int i=0; i < count; i++){
        getline(inputFileStream, line);

        stringstream ss(line);
        vector<float> numbers;

        for(int k = 0; k < 3; k++) {
            string aux;
            ss >> aux;

            float j = stof(aux);
            numbers.push_back(j);
        }

        Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
        normais.push_back(p);

    }

    getline(inputFileStream, line);

    count = stoi(line);


    for(int i=0; i < count; i++){
        getline(inputFileStream, line);

        stringstream ss(line);
        vector<float> numbers;

        for(int k = 0; k < 3; k++) {
            string aux;
            ss >> aux;

            float j = stof(aux);
            numbers.push_back(j);
        }

        Ponto *p = new Ponto(numbers.at(0),numbers.at(1),numbers.at(2));
        texturas.push_back(p);

    }

    int texID = 0;
    if(!textura.empty()) {
        texID = loadTexture(textura);
    }

    Figura *figura = new Figura(pontos,normais,texturas,texID,m,vf);

    return figura;


}

ViewFrustumeColisao* parseViewFrustum(XMLElement* elemento){
    bool esfera = true;
    float raio = 0;
    vector<Ponto*> pontosC;

    if(elemento->Attribute("limit")){
        const char* xAux = elemento->Attribute("limit");
        if(xAux[0] == 'E'){
            esfera = true;
            if(elemento->Attribute("raio")){
                const char* xAux = elemento->Attribute("raio");
                float x = atof(xAux);
                raio = x;
            }
        }

        else{
            esfera=false;
            elemento = elemento->NextSiblingElement("P");
            for(int i = 0; i < 8 && elemento; i++){
                float x=0,y=0,z=0;
                if(elemento->Attribute("X")){
                    const char* xAux = elemento->Attribute("X");
                    x = atof(xAux);

                }
                if(elemento->Attribute("Y")){
                    const char* yAux = elemento->Attribute("Y");
                    y = atof(yAux);

                }
                if(elemento->Attribute("Z")){
                    const char* zAux = elemento->Attribute("Z");
                    z = atof(zAux);

                }

                Ponto* p = new Ponto(x,y,z);
                pontosC.push_back(p);

                elemento = elemento->NextSiblingElement("P");

            }
        }

    }

    ViewFrustumeColisao* res = new ViewFrustumeColisao(esfera,pontosC,raio);

    return res;
}
Material* parseMaterial(XMLElement* elemento){
    Cor* emissiva = nullptr;
    Cor* especular = nullptr;
    Cor* difusa=  nullptr;
    Cor* ambiente = nullptr;
    float shininess = -1;
    float x,y,z;

    if(elemento->Attribute("emiR") || elemento->Attribute("emiG")|| elemento->Attribute("emiB")){
        emissiva = new Cor(0,0,0);
        if(elemento->Attribute("emiR")){
            const char* xAux = elemento->Attribute("emiR");
            x = atof(xAux);
            emissiva->setR(x);
        }
        if(elemento->Attribute("emiG")){
            const char* yAux = elemento->Attribute("emiG");
            y = atof(yAux);
            emissiva->setG(y);;
        }
        if(elemento->Attribute("emiB")){
            const char* zAux = elemento->Attribute("emiB");
            z = atof(zAux);
            emissiva->setB(z);
        }
    }
    if(elemento->Attribute("specR") || elemento->Attribute("specG")|| elemento->Attribute("specB")){
        especular = new Cor(0,0,0);
        if(elemento->Attribute("specR")){
            const char* xAux = elemento->Attribute("specR");
            x = atof(xAux);
            especular->setR(x);
        }
        if(elemento->Attribute("specG")){
            const char* yAux = elemento->Attribute("specG");
            y = atof(yAux);
            especular->setG(y);
        }
        if(elemento->Attribute("specB")){
            const char* zAux = elemento->Attribute("specB");
            z = atof(zAux);
            especular->setB(z);
        }
    }

    if(elemento->Attribute("diffR") || elemento->Attribute("diffG")|| elemento->Attribute("diffB")){
        difusa = new Cor(0.8,0.8,0.8);
        if(elemento->Attribute("diffR")){
            const char* xAux = elemento->Attribute("diffR");
            x = atof(xAux);
            difusa->setR(x);
        }
        if(elemento->Attribute("diffG")){
            const char* yAux = elemento->Attribute("diffG");
            y = atof(yAux);
            difusa->setG(y);
        }
        if(elemento->Attribute("diffB")){
            const char* zAux = elemento->Attribute("diffB");
            z = atof(zAux);
            difusa->setB(z);
        }
    }

    if(elemento->Attribute("ambR") || elemento->Attribute("ambG")|| elemento->Attribute("ambB")){
        ambiente = new Cor(0,0,0);
        if(elemento->Attribute("ambR")){
            const char* xAux = elemento->Attribute("ambR");
            x = atof(xAux);
            ambiente->setR(x);
        }
        if(elemento->Attribute("ambG")){
            const char* yAux = elemento->Attribute("ambG");
            y = atof(yAux);
            ambiente->setG(y);
        }
        if(elemento->Attribute("ambB")){
            const char* zAux = elemento->Attribute("ambB");
            z = atof(zAux);
            ambiente->setB(z);
        }
    }

    if(elemento->Attribute("shine")){
        const char* zAux = elemento->Attribute("shine");
        z = atof(zAux);
        shininess = z;
    }

    if( (emissiva == nullptr ) && (difusa == nullptr ) && (especular == nullptr ) && (ambiente == nullptr ) && (shininess == -1) ){

        return nullptr;
    }

    else{
        if( emissiva == nullptr) {
            emissiva = new Cor(0,0,0);
        }

        if( ambiente == nullptr) {
            ambiente = new Cor(0.2,0.2,0.2);
        }

        if( difusa == nullptr) {
            difusa = new Cor(0.8,0.8,0.8);
        }

        if( especular == nullptr) {
            especular = new Cor(0,0,0);
        }

        if( shininess < 0 || shininess > 128 ){
            shininess = 0;
        }

    }

    Material * material = new Material(difusa,ambiente,especular,emissiva,shininess);
}

void parseModelos(XMLElement *elemento, Grupo* g){
	
	//cout << "Estou na parseModelos" << endl;

	XMLElement * pElement = elemento->FirstChildElement("model");

	while (pElement != nullptr){

		const char* cenas = pElement->Attribute("file");
		if (cenas != nullptr){
            string fich(cenas, strlen(cenas));
            string textura;
            Material* material = nullptr;
            const char* xAux = pElement->Attribute("texture");
            if(xAux!= nullptr){

                string texAux(xAux,strlen(xAux));
                //cout << "Textura: " << texAux << endl;
                textura = texAux;
            }

            material = parseMaterial(pElement);

            ViewFrustumeColisao * vf = parseViewFrustum(pElement);

            Figura* f = extraiFicheiro(fich,textura,material,vf);
            g->adicionaFigura(f);

        }// return XML_ERROR_PARSING_ATTRIBUTE;



		//cout << "Ficheiro " << fich << endl;
		pElement = pElement->NextSiblingElement("model");
	
	}
}

void parseLuz(float* pos, XMLElement* elemento){
    float x=0,y=0,z=0;

    if(elemento->Attribute("posX")){
        const char* xAux = elemento->Attribute("posX");
        x = atof(xAux);
        pos[0] = x;
    }
    if(elemento->Attribute("posY")){
        const char* yAux = elemento->Attribute("posY");
        y = atof(yAux);
        pos[1] = y;
    }
    if(elemento->Attribute("posZ")){
        const char* zAux = elemento->Attribute("posZ");
        z = atof(zAux);
        pos[2] = z;
    }

}

void parseLuzPontual(XMLElement* elemento,Grupo* grupo){


    //cout << "Estou na parseRotacao" << endl;


    float pos[4] = {0,0,0,1};
    float atenuacao = 0;

    if(elemento){
        float tempo=0;

        parseLuz(pos,elemento);

        if(elemento->Attribute("atenuation")){
            const char* tempoAux = elemento->Attribute("atenuation");
            tempo = atof(tempoAux);
            atenuacao = tempo;
        }

        LuzPontual* l = new LuzPontual(pos,nrLuz++,atenuacao);
        grupo->adicionaLuz(l);
        //cout << "Rotacao" << endl;
        //cout << "X: " << x << "!Y: " << y << "!Z: " << z << "!Angulo: " << angulo << endl;
    }
}

void parseLuzDirecional(XMLElement* elemento,Grupo* grupo){


    //cout << "Estou na parseRotacao" << endl;


    float pos[4] = {0,0,1,0};


    if(elemento){

        parseLuz(pos,elemento);

        LuzDirecional* l = new LuzDirecional(pos,nrLuz++);
        grupo->adicionaLuz(l);
        //cout << "Rotacao" << endl;
        //cout << "X: " << x << "!Y: " << y << "!Z: " << z << "!Angulo: " << angulo << endl;
    }
}

void parseLuzFoco(XMLElement* elemento,Grupo* grupo){


    //cout << "Estou na parseRotacao" << endl;


    float pos[4] = {0,0,0,1};
    float atenuacao = 0;
    float direcao[3] = {0,0,-1};
    float angulo = 180;
    float expoente = 0;

    if(elemento){
        float tempo=0;
        float x=0,y=0,z=0;

        parseLuz(pos,elemento);

        if(elemento->Attribute("atenuation")){
            const char* tempoAux = elemento->Attribute("atenuation");
            tempo = atof(tempoAux);
            atenuacao = tempo;
        }

        if(elemento->Attribute("cut_off")){
            const char* tempoAux = elemento->Attribute("cut_off");
            tempo = atof(tempoAux);

            if(tempo >= 0 && tempo <= 90){
                angulo = tempo;
            }

        }

        if(elemento->Attribute("exponent")){
            const char* tempoAux = elemento->Attribute("exponent");
            tempo = atof(tempoAux);
            if(tempo > 0 && tempo <= 128) {
                expoente = tempo;
            }
        }

        if(elemento->Attribute("dirX")){
            const char* xAux = elemento->Attribute("dirX");
            x = atof(xAux);
            direcao[0] = x;
        }
        if(elemento->Attribute("dirY")){
            const char* yAux = elemento->Attribute("dirY");
            y = atof(yAux);
            direcao[1] = y;
        }
        if(elemento->Attribute("dirZ")){
            const char* zAux = elemento->Attribute("dirZ");
            z = atof(zAux);
            direcao[2] = z;
        }



        LuzFoco* l = new LuzFoco(pos,nrLuz++,angulo,direcao,atenuacao,expoente);
        grupo->adicionaLuz(l);
        //cout << "Rotacao" << endl;
        //cout << "X: " << x << "!Y: " << y << "!Z: " << z << "!Angulo: " << angulo << endl;
    }
}

void parseLuzes(XMLElement *elemento, Grupo* g){

    //cout << "Estou na parseModelos" << endl;

    XMLElement * pElement = elemento->FirstChildElement("light");

    while (pElement != nullptr){

       if(pElement->Attribute("type")){

           if(strcmp(pElement->Attribute("type"),"POINT")==0){
                parseLuzPontual(pElement,g);
           }

           if(strcmp(pElement->Attribute("type"),"SPOT")==0){
               parseLuzFoco(pElement,g);
           }

           if(strcmp(pElement->Attribute("type"),"DIRECTIONAL")==0){
               parseLuzDirecional(pElement,g);
           }

       }

        pElement = pElement->NextSiblingElement("light");
    }
}


void parseRotacao(XMLElement* elemento,Grupo* grupo){
	

	//cout << "Estou na parseRotacao" << endl;

	if(elemento){
		float x=0,y=0,z=0,angulo=0,tempo=0;

		if(elemento->Attribute("angle")){
			const char* anguloAux = elemento->Attribute("angle");
			angulo = atof(anguloAux);
		}
		
		if(elemento->Attribute("axisX")){
			const char* xAux = elemento->Attribute("axisX");
			x = atof(xAux);
		}
		if(elemento->Attribute("axisY")){
			const char* yAux = elemento->Attribute("axisY");
			y = atof(yAux);
		}
		if(elemento->Attribute("axisZ")){
			const char* zAux = elemento->Attribute("axisZ");
			z = atof(zAux);
		}

        if(elemento->Attribute("time")){
            const char* tempoAux = elemento->Attribute("time");
            tempo = atof(tempoAux);
        }

		Rotacao* r = new Rotacao(x,y,z,angulo,tempo);
		grupo->adicionaOperacao(r);
		//cout << "Rotacao" << endl;
		//cout << "X: " << x << "!Y: " << y << "!Z: " << z << "!Angulo: " << angulo << endl;
	}
}

vector<Ponto*> parsePontosTranslacao(XMLElement* elemento){
	vector<Ponto*> pontos;
    while((elemento) && (strcmp(elemento->Name(),"point") == 0)){

        float x=0,y=0,z=0;
        if(elemento->Attribute("X")){
            const char* xAux = elemento->Attribute("X");
            x = atof(xAux);
        }
        if(elemento->Attribute("Y")){
            const char* yAux = elemento->Attribute("Y");
            y = atof(yAux);
        }
        if(elemento->Attribute("Z")){
            const char* zAux = elemento->Attribute("Z");
            z = atof(zAux);
        }

        Ponto* p = new Ponto(x,y,z);
        pontos.push_back(p);
		//cout << "PontoTranslacao! X: " << x << "!Y: " << y << "!Z: " << z << endl;
		elemento = elemento->NextSiblingElement();
    }
	return pontos;
}

void parseTranslacao(XMLElement* elemento,Grupo* grupo){
	bool mostraCurva = true;

	//cout << "Estou na parseTranslacao" << endl;
	//cout << elemento->Name() << endl;

	//XMLElement *pElement = elemento->FirstChildElement("translate");
	if(elemento){
		float x=0,y=0,z=0,tempo=0;
        vector<Ponto*> pontos;
		if(elemento->Attribute("X")){
			const char* xAux = elemento->Attribute("X");
			x = atof(xAux);
		}
		if(elemento->Attribute("Y")){
			const char* yAux = elemento->Attribute("Y");
			y = atof(yAux);
		}
		if(elemento->Attribute("Z")){
			const char* zAux = elemento->Attribute("Z");
			z = atof(zAux);
		}
        if(elemento->Attribute("time")){
                const char* tempoAux = elemento->Attribute("time");
                tempo = atof(tempoAux);
                XMLElement* elementoFilho = elemento->FirstChildElement("point");
                pontos = parsePontosTranslacao(elementoFilho);

                if(pontos.size() < 4){
                    tempo = 0;
                }
        }

        if(elemento->Attribute("NC")){
            mostraCurva = false;
        }

		Translacao* r = new Translacao(x,y,z,tempo,pontos,mostraCurva);
		grupo->adicionaOperacao(r);
		//cout << "Translacao! X: " << x << "!Y: " << y << "!Z: " << z << "Tempo: " << tempo << "Mostra? " << mostraCurva << endl;
	}
}

void parseEscala(XMLElement* elemento,Grupo* grupo){

	
	//cout << "Estou na parseEscala" << endl;

	if(elemento){
		float x=1,y=1,z=1;
		
		if(elemento->Attribute("X")){
			const char* xAux = elemento->Attribute("X");
			x = atof(xAux);
		}
		if(elemento->Attribute("Y")){
			const char* yAux = elemento->Attribute("Y");
			y = atof(yAux);
		}
		if(elemento->Attribute("Z")){
			const char* zAux = elemento->Attribute("Z");
			z = atof(zAux);
		}

		Escala* r = new Escala(x,y,z);
		grupo->adicionaOperacao(r);
		//cout << "X: " << x << "!Y: " << y << "!Z: " << z << endl;
	}
}

void parseOperacoes(XMLElement** elemento,Grupo* grupo){

	
	//cout << "Estou na parseOperacoes" << endl;

	if(strcmp((*elemento)->Name(),"rotate") == 0){
		parseRotacao(*elemento,grupo);
	}

	else{
 		if(strcmp((*elemento)->Name(),"scale") == 0){
			parseEscala(*elemento,grupo);
		}
		
		else{
			if(strcmp((*elemento)->Name(),"translate") == 0){
				parseTranslacao(*elemento,grupo);
			}
			
			else{
				return;			
			}
		}
	}
	
	(*elemento)=(*elemento)->NextSiblingElement();
	
	if(*elemento){
		parseOperacoes(elemento,grupo);
	}
}

Grupo* parseGrupo(XMLElement* elemento){
	Grupo* res = new Grupo(numeroGrupo++);

	//XMLElement* inicial = elemento;

	//cout << "Estou na parseGrupo" << endl;
    if(strcmp(elemento->Name(),"lights") == 0){
        parseLuzes(elemento, res);
        elemento = elemento->NextSiblingElement();
        //cout << "Fim parse Modelos!" << endl;
        // cout << elemento->Name() << endl;
    }

	parseOperacoes(&elemento,res);

	//cout << elemento->Name() << endl;

	if(strcmp(elemento->Name(),"models") == 0){
		parseModelos(elemento, res);
		elemento = elemento->NextSiblingElement();
		//cout << "Fim parse Modelos!" << endl;
		// cout << elemento->Name() << endl;
	}

	while((elemento) && (strcmp(elemento->Name(),"group") == 0)){

		XMLElement *elementoFilho = elemento->FirstChildElement();
		if(elementoFilho){
			//cout << "FAZER PARSE GRUPO!" << endl;
			Grupo* filho = parseGrupo(elementoFilho);
			res->adicionaGrupo(filho);
			//cout << "FIM PARSE GRUPO" << endl;
		}
		
		elemento = elemento->NextSiblingElement();
	}			
		
	return res;
}

Grupo* parseFile(char* filename){

	XMLDocument xmlDoc;
	XMLError eResult = xmlDoc.LoadFile(filename);

	XMLCheckResult(eResult);

	
	Grupo* grupos;

	if(eResult != 0){
		cout << "ERRO!" << endl;
		return grupos;//nullptr;
	}

	XMLElement * elemento = xmlDoc.FirstChildElement("scene")->FirstChildElement("group");

	if(elemento != nullptr){

		XMLElement * elementoFilho = elemento->FirstChildElement();
		//cout << elemento->Name() << endl;

		if(elementoFilho != nullptr){
				grupos = parseGrupo(elementoFilho);

		}
	
	}

	//if(grupos != nullptr){
		return grupos;
	//}

	//return nullptr;
}