#ifndef __LuzFoco_H__
#define __LuzFoco_H__

#include <GL/glew.h>
#include <math.h>
#include <string>
#include <vector>

#include "Ponto.h"
#include "Luz.h"
#include <GL/glut.h>
#include <IL/il.h>

using namespace std;

class LuzFoco : public Luz {
	
private:
	
	float angulo;
	float direcao[3];
	float atenuacao;
	float expoente;

public:
	LuzFoco();
	
	LuzFoco(float[4], int,float,float[3],float,float);
    	
	void desenhaLuz();

};
		

#endif
