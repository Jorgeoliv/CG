//
// Created by jose on 03-03-2018.
//

#ifndef ESTRUTURAS_PATCH_H
#define ESTRUTURAS_PATCH_H


#include <string>
#include <vector>
#include "Ponto.h"

using namespace std;

class Patch {
private:
	vector<vector<int>> indices;
	vector<Ponto*> pontos;

public:
    Patch();
    Patch(vector<vector<int>>, vector<Ponto*>);
    Patch(Patch &p);

    vector<vector<int>> getIndices();
    vector<Ponto*> getPontos();

    string toString();

};


#endif //ESTRUTURAS_PONTO_H
