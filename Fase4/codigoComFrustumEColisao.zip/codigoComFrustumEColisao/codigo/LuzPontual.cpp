#include "LuzPontual.h"

LuzPontual::LuzPontual() : Luz(){}

LuzPontual::LuzPontual(float p[4],int nr,float at) : Luz(nr,p) {
	atenuacao = at;
}

void LuzPontual::desenhaLuz(){

	int luzA = this->getNumero();

	if(luzA>7){
		luzA = 7;
	}

	// posicao
	glLightfv(GL_LIGHT0 +luzA, GL_POSITION, this->getPosicao());
	
	// cores
	glLightfv(GL_LIGHT0 +luzA, GL_AMBIENT, this->getAmbiente());
	glLightfv(GL_LIGHT0 +luzA, GL_DIFFUSE, this->getDifusa());
	glLightfv(GL_LIGHT0 +luzA, GL_DIFFUSE, this->getEspecular());

	//atenuacao
	glLightf(GL_LIGHT0 +luzA,GL_LINEAR_ATTENUATION,atenuacao);



}
