#ifndef __Cor_H__
#define __Cor_H__

class Cor{

	float r;
	float g;
	float b;

	public:
		Cor();
		Cor(float,float,float);
		float getR();
		float getG();
		float getB();
		void setR(float);
		void setG(float);
		void setB(float);
		Cor* clone();

};

#endif
