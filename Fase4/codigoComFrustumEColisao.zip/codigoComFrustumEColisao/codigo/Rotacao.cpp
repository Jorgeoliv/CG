#include "Rotacao.h"
#include <iostream>

using namespace std;


Rotacao::Rotacao() : Operacao() {
	tempo = 0;
}


Rotacao::Rotacao(float x, float y, float z, float angulo, float tempo)
      : Operacao(x, y, z){
	this->angulo = angulo;
	this->tempo = tempo;
}


float Rotacao::getAngulo(){
	return angulo;
}


void Rotacao::setAngulo(float a){
	angulo=a;
}

float Rotacao::getTempo(){
	return tempo;
}


void Rotacao::setTempo(float a){
	tempo=a;
}

void Rotacao::aplicaOperacao(glm::mat4 * matriz){
	if(tempo==0){
      // cout << "Rotacao Angulo: " << angulo << endl;
        float anguloRad = (angulo*M_PI/180);
		glRotatef(angulo,getX(),getY(),getZ());
		(*matriz) = glm::rotate(*matriz,anguloRad,glm::vec3(getX(),getY(),getZ()));
	}

	else{

        cout << "Rotacao Tempo: " << tempo << endl;

		float tempoDecorrido = glutGet(GLUT_ELAPSED_TIME);
		float percentagem = tempoDecorrido / (tempo * 1000);

		percentagem = percentagem - floor(percentagem);

		glRotatef(360*percentagem,getX(),getY(),getZ());
		//(*matriz) = glm::rotate(*matriz,360*percentagem,glm::vec3(getX(),getY(),getZ()));
	}
}

string Rotacao::toString(){
	string res= "";
	cout << "Rotacao:		X: " << getX() << "	Y: " << getY() << "	Z: " << getZ() << "	Ang: " << angulo << endl;

	return res;
}