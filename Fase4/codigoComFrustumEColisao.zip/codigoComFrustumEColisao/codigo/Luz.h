#ifndef __Luz_H__
#define __Luz_H__

#include "Ponto.h"
#include <GL/glut.h>
#include <IL/il.h>

using namespace std;

class Luz {
	
private:
	float posicao[4];
	float ambiente[4] = {0,0,0, 1};;
	float difusa[4] = {0,0,0, 1};;
	float especular[4] = {0,0,0, 1};;
	int numero;

public:
	Luz();
	
	Luz(int, float[4]);

	GLfloat* getPosicao();
	GLfloat* getAmbiente();
	GLfloat* getDifusa();
	GLfloat* getEspecular();

	int getNumero();
    	
	virtual void desenhaLuz() = 0;

};
		

#endif
