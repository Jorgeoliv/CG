#ifndef UNTITLED_CAMERA_H
#define UNTITLED_CAMERA_H

#include <string>
#include "Ponto.h"
#include <math.h>
#include "FrustumG.h"
#include <GL/glut.h>

class Camera{



    float alpha;
    float beta;
    int mouseX;
    int mouseY;
    int mouseTracking;
    Ponto* posicao;
    Ponto* foco;
    Vec3 camVecX;
    Vec3 camVecY;
    Vec3 camVecZ;
    float angulo;
    float velocidade;
    FrustumG* frustum;

    float mX;
    float mY;
    float mZ;


public:
    Camera();
    Camera(float,float,float);
    void alteraFocoCamera();
    void alteraVetoresCamera();
    void alteraPosicaoCamera(float,float,float);
    void mouseButtons(int button, int state, int xx, int yy);
    bool mouseMotion(int xx, int yy);
    bool normalKeys(unsigned char c, int xx, int yy);
    void specialKeys(int key, int xx, int yy);
    Ponto* getPosicao();
    Ponto* getFoco();
    void setFrustumDef();
    void setFrustumInternals(float,float,float,float);
    void setPosicao(Ponto*);
    void voltaAtras();

    Plane* getFrustumPlanos();
};
#endif
