#include "Camera.h"


Camera::Camera(float x, float y, float z){

    posicao = new Ponto(x,y,z);
    foco = new Ponto(0.0f,0.0f,0.0f);
    camVecX;
    camVecY;
    camVecZ;
    alpha = 0;
    beta  = 0;
    mouseX = -1;
    mouseY = -1;
    mouseTracking = 0;
    angulo = 0.5;
    velocidade = 0.3;
    frustum = new FrustumG();
    alteraFocoCamera();

}


Ponto* Camera::getPosicao() {

    return posicao;
}


Ponto* Camera::getFoco() {

    return foco;
}


void Camera::alteraVetoresCamera(){

    float v = velocidade;
    float dx = foco->getX() - posicao->getX();
    float dy = foco->getY() - posicao->getY();
    float dz = foco->getZ() - posicao->getZ();
    Vec3 d(dx, dy, dz);

    Vec3 upAux(0,1,0);
    (camVecZ = -d).normalize();
    (camVecX = upAux*camVecZ).normalize();
    (camVecY = camVecZ*camVecX).normalize();
}

void Camera::setPosicao(Ponto *p) {
    posicao = p;
    alteraFocoCamera();
}


void Camera::alteraFocoCamera(){

    float focoX = posicao->getX() + sin(-alpha * 3.14 / 180.0) * cos(-beta * 3.14 / 180.0);
    float focoY = posicao->getY() +                              sin(-beta * 3.14 / 180.0);
    float focoZ = posicao->getZ() + cos(-alpha * 3.14 / 180.0) * cos(-beta * 3.14 / 180.0);
    foco->set(focoX, focoY, focoZ);

    alteraVetoresCamera();
}

void Camera::alteraPosicaoCamera(float x, float y, float z) {

    Vec3 move(posicao->getX() , posicao->getY() , posicao->getZ());
    //printf("PosAntes: X: %f! Y: %f! Z : %f\n",move.x, move.y, move.z);
    move = move + (camVecX*x + camVecY*y+ camVecZ*z)*velocidade;

    //printf("Move: X: %f! Y: %f! Z : %f\n",move.x, move.y, move.z);
    posicao->set(move.x, move.y, move.z);

    //printf("Pos: X: %f! Y: %f! Z : %f\n",posicao->getX(),posicao->getY(),posicao->getZ());

    alteraFocoCamera();
}

/*
void Camera::alteraPosicaoCamera(int a, int b, int c) {

    float v = velocidade;
    float dx = foco->getX() - posicao->getX();
    float dy = foco->getY() - posicao->getY();
    float dz = foco->getZ() - posicao->getZ();

    if (b == 0) {
        posicao->addPonto(a*v*dz, 0, c*v*dx);
        foco->addPonto(a*v*dz, 0, c*v*dx);
    }
    else{
        posicao->addPonto(a*v*dx, b*v*dy, c*v*dz);
        foco->addPonto(a*v*dx, b*v*dy, c*v*dz);
    }
}
*/

void Camera::mouseButtons(int button, int state, int xx, int yy) {

    if (state == GLUT_DOWN)  {
        mouseX = xx;
        mouseY = yy;
        if (button == GLUT_LEFT_BUTTON)
            mouseTracking = 1;
        else if (button == GLUT_RIGHT_BUTTON)
            mouseTracking = 2;
        else
            mouseTracking = 0;
    }
    else if (state == GLUT_UP)
        mouseTracking = 0;
}


bool Camera::mouseMotion(int xx, int yy) {

    float deltaX, deltaY;
    float alphaAux, betaAux;
    float rAux;

    if (!mouseTracking)
        return false;

    deltaX = xx - mouseX;
    deltaY = yy - mouseY;

    mouseX = xx;
    mouseY = yy;

    if (mouseTracking == 1) {

        alpha += deltaX*angulo;
        beta += deltaY*angulo;

        if (beta > 85.0)
            beta = 85.0;
        else if (beta < -85.0)
            beta = -85.0;

        alteraFocoCamera();
    }

    else if (mouseTracking == 2) {
        alteraPosicaoCamera(0,0,deltaY);
        mX = 0; mY = 0; mZ = -deltaY;
        return true;
    }
    return false;
}


bool Camera::normalKeys(unsigned char c, int xx, int yy) {
    Vec3 move;
    bool res = false;

    switch (c) {
        case 27:
            exit(0);

        case '+':
            velocidade *= 1.33;
            if(velocidade > 0.5)
                velocidade = 0.5;
            break;

        case '-':
            velocidade *= 0.67;
            if(velocidade < 0.005)
                velocidade = 0.01;
            break;

        case 'w':
            res = true;

            alteraPosicaoCamera(0,0,-1);
            mX = 0;
            mY = 0;
            mZ = 1;
            break;

        case 's':
            res = true;
            alteraPosicaoCamera(0,0,+1);
            mX = 0;
            mY = 0;
            mZ = -1;
            break;

        case 'a':
            res = true;
            alteraPosicaoCamera(-1,0,0);
            mX = 1;
            mY = 0;
            mZ = 0;
            break;

        case 'd':
            res = true;
            alteraPosicaoCamera(+1,0,0);
            mX = -1;
            mY = 0;
            mZ = 0;
            break;

        case 'c':
            res = true;
            alteraPosicaoCamera(0,+1,0);
            mX = 0;
            mY = -1;
            mZ = 0;
            break;

        case 'b':
            res = true;
            alteraPosicaoCamera(0,-1,0);
            mX = 0;
            mY = 1;
            mZ = 0;
            break;
    }

    //printf("Retornando %d\n",res);

    return res;
}


void Camera::specialKeys(int key, int xx, int yy) {

    switch (key) {

        case GLUT_KEY_RIGHT:
            alpha += angulo;
            alteraFocoCamera();
            break;

        case GLUT_KEY_LEFT:
            alpha -= angulo;
            alteraFocoCamera();
            break;

        case GLUT_KEY_UP:
            beta -= angulo;
            alteraFocoCamera();
            break;

        case GLUT_KEY_DOWN:
            beta += angulo;
            alteraFocoCamera();
            break;

        case GLUT_KEY_PAGE_DOWN:
            angulo *= 0.67;
            break;

        case GLUT_KEY_PAGE_UP:
            angulo *= 1.33;
            break;
    }
}

void Camera::setFrustumDef(){
    Vec3 p(posicao->getX(),posicao->getY(),posicao->getZ());
    Vec3 l(foco->getX(),foco->getY(),foco->getZ());
    Vec3 u(0,1,0);
    frustum->setCamDef(p,l,u);
}

void Camera::setFrustumInternals(float a, float b, float c, float d){
    frustum->setCamInternals(a,b,c,d);
}

Plane* Camera::getFrustumPlanos(){
    return frustum->pl;
}

void Camera::voltaAtras(){

    /*printf("Voltando atrás: x: %f! y: %f! z: %f!\n", mX,mY,mZ);

    printf("Vecx: %f! %f! %f\n", camVecX.x, camVecX.y, camVecX.z);
    printf("Vecy: %f! %f! %f\n", camVecY.x, camVecY.y, camVecY.z);
    printf("Vecz: %f! %f! %f\n", camVecZ.x, camVecZ.y, camVecZ.z);
*/
   alteraPosicaoCamera(mX,mY,mZ);
}
