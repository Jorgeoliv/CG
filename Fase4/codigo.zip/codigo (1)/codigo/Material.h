#ifndef __MATERIAL_H__
#define __MATERIAL_H__

#include <GL/glut.h>
#include <iostream>

#include "Cor.h"


using namespace std;

class Material{

	float difusa[4]; 	// default: {0.8, 0.8, 0.8, 1};
	float ambiente[4]; 	// default: {0.2, 0.2, 0.2, 1};
	float especular[4]; 	// default: {0, 0, 0, 1};
	float emissiva[4]; 	// default: {0, 0, 0, 1};
	float shininess; 	// default: 0;

	public:
		Material();
		Material(Cor*, Cor*, Cor*, Cor*, float);
		void desenha();
};


#endif