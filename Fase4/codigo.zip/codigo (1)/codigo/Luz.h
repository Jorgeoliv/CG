#ifndef __Luz_H__
#define __Luz_H__

#include "Ponto.h"
#include <GL/glut.h>
#include <IL/il.h>

using namespace std;

class Luz {
	
private:
	float posicao[4];
	float ambiente[4];
	float difusa[4];
	float especular[4];

public:
	Luz();
	
	Luz(float[4],float[4],float[4],float[4]);

	GLfloat* getPosicao();
	GLfloat* getAmbiente();
	GLfloat* getDifusa();
	GLfloat* getEspecular();
    	
	virtual void desenhaLuz() = 0;

};
		

#endif
