#include "LuzFoco.h"

LuzFoco::LuzFoco() : Luz(){}

LuzFoco::LuzFoco(float p[4],float d[4],float amb[4],float e[4],float a,float dir[3],float at, float exp) : Luz(p,d,amb,e) {
	angulo = a;

	atenuacao = at;
	expoente = exp;

	for(int i=0; i<3;i++){
		direcao[i] = dir[i];
	}
}

void LuzFoco::desenhaLuz(){



	// posicao
	glLightfv(GL_LIGHT0, GL_POSITION, this->getPosicao());
	
	// cores
	glLightfv(GL_LIGHT0, GL_AMBIENT, this->getAmbiente());
	glLightfv(GL_LIGHT0, GL_DIFFUSE, this->getDifusa());
	glLightfv(GL_LIGHT0, GL_DIFFUSE, this->getEspecular());

	//da spot
	glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, direcao);
	glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, angulo);
	glLightf(GL_LIGHT0,GL_SPOT_EXPONENT, expoente); 

	//atenuacao
	glLightf(GL_LIGHT0,GL_LINEAR_ATTENUATION,atenuacao);

}
