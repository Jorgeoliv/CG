#ifndef __TRANSLACAO_H__
#define __TRANSLACAO_H__

#include "Operacao.h"
#include <GL/glut.h>

using namespace std;

class Translacao: public Operacao {

private:
float tempo;
vector<Ponto*> pontos;
vector<Ponto*> curva;
float upY[3];

	void normalize(float*);
	void getCatmullRomPoint(float,int*,float*,float*);
	void getGlobalCatmullRomPoint(float,float*,float*);
	void rodaElemento(float*);

public:
	Translacao();
    Translacao(float,float,float,float,vector<Ponto*>);

    float getTempo();
    void setTempo(float);

    vector<Ponto*> getPontos();
    void setPontos(vector<Ponto*>);


    vector<Ponto*> getCurva();
    
    void aplicaOperacao();

	void renderCatmullRomCurve();

    string toString();
};
		

#endif
