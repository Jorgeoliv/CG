#include "ViewFrustumeColisao.h"
#include <vector>
#include <iostream>
#include <cmath>
#include <GL/glut.h>

using namespace std;

ViewFrustumeColisao::ViewFrustumeColisao(){}

ViewFrustumeColisao::ViewFrustumeColisao(bool e,vector<Ponto*> v,float o){
    esfera=e;

    if(e){
        raio = o;
    }

    else{
        pontosControlo = v;

        if(v.size()==0) return;
        raio = sqrt(pow(v.at(0)->getX(),2) + pow(v.at(0)->getY(),2) + pow(v.at(0)->getZ(),2));
    }


}

float ViewFrustumeColisao::distancia(float pl[4], float p[4]){

    float res = 0.0f;

    for(int i = 0; i < 4; i++){

        res += pl[i]*p[i];
    }

    return res;
}

void ViewFrustumeColisao::multiplicaMatriz(float p[4], float tg[16]){

    float aux[4];

    for(int i=0;i<4;i++){

        float valor = 0.0f;
        for(int j=0;j<4;j++){
            valor += p[j]*tg[i*4+j];
        }

        aux[i] = valor;
    }

    for(int i = 0; i < 4; i++){
        p[i] = aux[i];
    }
}


bool ViewFrustumeColisao::estaDentroEsfera(Plane planos[6], float centro[4]){

        float distancia;
        bool result = true;
        int n = planoRejeitado;
        for(int i=0; i < 6; i++) {
            Vec3 c1 (centro[0],centro[1],centro[2]);
            distancia = planos[n].distance(c1);
            if (distancia < -raio) {
                planoRejeitado = n;
                return false;

            }
            n = (n+1)%6;
        }
        return(result);
}

bool ViewFrustumeColisao::estaDentroCaixa(Plane planos[6]){

    int n = planoRejeitado;
    for(int i = 0; i < 6; i++){

        float p[4] = {0,0,0,1};
        p[0] = coordenadas[1];
        p[1] = coordenadas[3];
        p[2] = coordenadas[5];

        if (planos[n].normal.x >= 0)
            p[0] = coordenadas[0];

        if (planos[n].normal.y >=0)
            p[1] = coordenadas[2];

        if (planos[n].normal.z >= 0)
            p[2] = coordenadas[4];

        Vec3 p1 (p[0],p[1],p[2]);
        float distancia = planos[n].distance(p1);

        if(distancia < 0) {
            planoRejeitado = n;
            return false;
        }

        n = (n+1) % 6;

    }

    return true;

}

void ViewFrustumeColisao::atualizaCoordenadas(float pontos[8][4]){

    for(int i = 0; i < 3; i++){
        coordenadas[i] = pontos[0][i];
        coordenadas[i+1] = pontos[0][i];
    }

    for(int i = 1; i < 8; i++){

        for(int j = 0; j < 3; j++){

            if(coordenadas[j] < pontos[i][j]){
                coordenadas[j] = pontos[i][j];
            }

            else{
                if(coordenadas[j+1] > pontos[i][j]){
                    coordenadas[j+1] = pontos[i][j];
                }
            }
        }
    }

}

bool ViewFrustumeColisao::estaDentro(Plane planos[6], glm::mat4 matriz){

    float tg[16];

    //cout << "Matriz" << endl;
    for(int i = 0; i < 4; i++){
        for(int j = 0; j < 4; j++){
            tg[4*i+j] = matriz[j][i];
      //      cout << tg[4*i+j] << "\t";
        }
        //cout << endl;
    }
    //cout << endl << endl;
    if(esfera){
        float centro[4] = {0,0,0,1};
        multiplicaMatriz(centro,tg);

        return this->estaDentroEsfera(planos,centro);
    }

    else{

        float pontos[8][4];
        for(int i = 0; i<8; i++){
            pontos[i][0] = pontosControlo.at(i)->getX();
            pontos[i][1] = pontosControlo.at(i)->getY();
            pontos[i][2] = pontosControlo.at(i)->getZ();
            pontos[i][3] = 1.0f;
        }

        for(int i = 0; i < 8; i++){

            multiplicaMatriz(pontos[i],tg);
        }

        this->atualizaCoordenadas(pontos);

        this->estaDentroCaixa(planos);

    }
}

bool ViewFrustumeColisao::possoMover(float pX,float pY,float pZ,float r,glm::mat4 matriz){

    //Posiciona o objeto consoante as transformacoes
    float tg[16];

    //cout << "Matriz" << endl;
    for(int i = 0; i < 4; i++){
        for(int j = 0; j < 4; j++){
            tg[4*i+j] = matriz[j][i];
            //      cout << tg[4*i+j] << "\t";
        }
        //cout << endl;
    }
    //cout << endl << endl;

    float centro[4] = {0,0,0,1};
    multiplicaMatriz(centro,tg);


    //Calcula a distancia entre o centro do objeto e a camara
    float dist = sqrt(pow(pX-centro[0],2)+pow(pY-centro[1],2)+pow(pZ-centro[2],2));

    //Verifica se a distancia é superior à soma dos raios das 2 esferas, se n for n pode mover (isto tem
    // um problema que é, deixa atravessar a esfera. Para o resolver só passando a posicao original e verificar
    // umas cenas com vetores, depois se tivermos tempo podemos fazer! Digam algo sff
    if(dist > (raio+r)){
        return true;
    }

    return false;

}
