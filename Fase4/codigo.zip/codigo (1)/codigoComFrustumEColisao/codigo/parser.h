#include "tinyxml2.h"
#include "Grupo.h"
#include "Rotacao.h"
#include "Translacao.h"
#include "Escala.h"
#include "Patch.h"
#include "LuzFoco.h"
#include "LuzDirecional.h"
#include "LuzPontual.h"
#include "Cor.h"
#include "ViewFrustumeColisao.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

Grupo* parseFile(char*);

Patch* extraiPatch(std::string filename);
