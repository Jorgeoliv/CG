#include "Luz.h"

Luz::Luz(){

}

Luz::Luz(float p[4],float d[4],float a[4],float e[4]){
	for(int i = 0; i < 4; i++){
		posicao[i]=p[i];
		difusa[i]=d[i];
		ambiente[i]=a[i];
		especular[i] = e[i];
	}
}

GLfloat* Luz::getPosicao(){

	return this->posicao;
}

GLfloat* Luz::getAmbiente(){

	return this->ambiente;
}

GLfloat* Luz::getDifusa(){

	return this->difusa;
}

GLfloat* Luz::getEspecular(){

	return this->especular;
}
