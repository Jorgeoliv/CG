#include "Luz.h"

Luz::Luz(){

}

Luz::Luz(float[4] p,float[4] d,float[4] a,float e[4]){
	for(int i = 0; i < 4; i++){
		posicao[i]=p[i];
		difusa[i]=d[i];
		ambiente[i]=a[i];
		especular[i] = e[i];
	}
}
