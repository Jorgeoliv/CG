#include "LuzDirecional.h"

LuzDirecional::LuzDirecional() : Luz(){}

LuzDirecional::LuzDirecional(float p[4] ,float d[4] ,float amb[4] ,float e[4] ) : Luz(p,d,amb,e) {
}

void LuzDirecional::desenhaLuz(){

	// posicao
	glLightfv(GL_LIGHT0, GL_POSITION, this->getPosicao());
	
	// cores
	glLightfv(GL_LIGHT0, GL_AMBIENT, this->getAmbiente());
	glLightfv(GL_LIGHT0, GL_DIFFUSE, this->getDifusa());
	glLightfv(GL_LIGHT0, GL_DIFFUSE, this->getEspecular());

}
