#include "LuzFoco.h"

LuzFoco::LuzFoco() : Luz(){}

LuzFoco::LuzFoco(float[4] p,float[4] d,float[4] amb,float[4] e,float a,float[3] dir,float at) : Luz(p,d,amb,e) {
	angulo = a;
	direcao = dir;
	atenuacao = at;
}

LuzFoco::void desenhaLuz();
