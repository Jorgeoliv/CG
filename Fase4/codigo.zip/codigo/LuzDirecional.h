#ifndef __LuzDirecional_H__
#define __LuzDirecional_H__

#include <GL/glew.h>
#include <math.h>
#include <string>
#include <vector>

#include "Ponto.h"
#include "Luz.h"
#include <GL/glut.h>
#include <IL/il.h>

using namespace std;

class LuzDirecional : public Luz {
	
private:
	
public:
	LuzDirecional();
	
	LuzDirecional(float[4],int);
    	
	void desenhaLuz();

};
		

#endif
