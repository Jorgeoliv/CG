#ifndef __ViewFrustumeColisao_H__
#define __ViewFrustumeColisao_H__

#include "Ponto.h"
#include "Plane.h"
#include <vector>

class ViewFrustumeColisao{

	bool esfera;
	vector<Ponto*> pontosControlo;
	float raio;
	float coordenadas[6];

	int planoRejeitado = -1;

	private:
		void atualizaCoordenadas(float[8][4]);
		float distancia(float pl[4], float p[4]);
		void multiplicaMatriz(float p[4], float tg[16]);
		bool estaDentroEsfera(Plane[6], float centro[4]);
		bool estaDentroCaixa(Plane[6]);
	public:
		ViewFrustumeColisao();
		ViewFrustumeColisao(bool,vector<Ponto*>,float);

		bool estaDentro(Plane[6]);

		bool possoMover(float,float,float,float);
		

};

#endif
