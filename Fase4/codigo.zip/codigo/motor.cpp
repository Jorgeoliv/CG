
#include "parser.h"
#include "Camera.h"
#include <stack>
//#include <glm/glm.hpp>


#define _USE_MATH_DEFINES
#include <math.h>

using namespace std;

//using namespace glm;


Camera* camera;

Grupo* cena;

//stack<glm::mat4> stackMatrizes;
// glm::mat4 matrizAtual;



void changeSize(int w, int h) {

    // Prevent a divide by zero, when window is too short
    // (you cant make a window with zero width).
    if(h == 0)
        h = 1;

    // compute window's aspect ratio
    float ratio = w * 1.0 / h;

    // Set the projection matrix as current
    glMatrixMode(GL_PROJECTION);
    // Load Identity Matrix
    glLoadIdentity();

    // Set the viewport to be the entire window
    glViewport(0, 0, w, h);

    // Set perspective
    gluPerspective(45.0f ,ratio, 1.0f ,1000.0f);

    camera->setFrustumInternals(45.0f,ratio,1.0f,100.0f);
    // return to the model view matrix mode
    glMatrixMode(GL_MODELVIEW);
}


void imprimeFigura(vector<Figura*> figuras){


    glColor3f(0.3,0.3,0.8);
    //glBegin(GL_TRIANGLES);

    //cout << "Imprimindo figura" << endl;

    for(Figura* f: figuras){

        f->desenha(camera->getFrustumPlanos());

    }

    glColor3f(0.9,0.9,0.9);

    glEnd();


}

void imprimeGrupo(Grupo* g){

    //cout << "Vou imprimir grupo" << endl;
    //if(g->getID() < 6 && g->getID()!=0) return;

    vector<Luz*> luzes = g->getLuzes();

    for(Luz* l: luzes){
        l->desenhaLuz();
    }

    glPushMatrix();
    //glm::mat4 aux = glm::mat4(matrizAtual);
    //stackMatrizes.push(aux);

    vector<Operacao*> operacoes = g->getOperacoes();
    for(Operacao* op: operacoes){
      //  cout << "Operacao" << endl;
        op->aplicaOperacao();
    }


    vector<Figura*> figuras = g->getFiguras();
    imprimeFigura(figuras);

    vector<Grupo*> gruposFilhos = g->getGrupos();
    for(Grupo* filho: gruposFilhos){
        imprimeGrupo(filho);
    }

    glPopMatrix();
    //matrizAtual = stackMatrizes.pop();

}

void percorreGrupos(){

    imprimeGrupo(cena);
    
}


void renderScene(void) {

    // clear buffers

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);

    glLoadIdentity();

    // set the camera
    Ponto* pos = camera->getPosicao();
    Ponto* foco = camera->getFoco();

    gluLookAt(pos->getX(),pos->getY(),pos->getZ(),
              foco->getX(),foco->getY(),foco->getZ(),
              0.0f,1.0f,0.0f);

    camera->setFrustumDef();

    glCullFace(GL_BACK);
    percorreGrupos();

    // End of frame
    glutSwapBuffers();
}


void processKeys(unsigned char c, int xx, int yy) {

    switch(c){

        case('p'): //visualizacao por pontos
            glPolygonMode(GL_FRONT, GL_POINT);
            break;

        case('t'): //visualizacao total
            glPolygonMode(GL_FRONT, GL_FILL);
            break;

        case('l'): //visualizacao por linhas
            glPolygonMode(GL_FRONT, GL_LINE);
            break;

        default:
            camera->normalKeys(c, xx, yy);
            break;
    }
}


void processSpecialKeys(int key, int xx, int yy) {

    camera->specialKeys(key, xx, yy);
}


void processMouseButtons(int button, int state, int xx, int yy) {

    camera->mouseButtons(button, state, xx, yy);
}


void processMouseMotion(int xx, int yy) {

    camera->mouseMotion(xx, yy);
}


void initGL(){
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);

    //converte();
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glClearColor(0, 0, 0, 0);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glEnable(GL_TEXTURE_2D);
}


int main(int argc, char **argv) {

    if(argc < 2){
        cout << "ERRO! Poucos argumentos." << endl;
        return 0;

    }

    camera = new Camera(5.0, 5.0, 5.0);

    glutInit(&argc, argv);
    ilInit();
    glutInitDisplayMode(GLUT_DEPTH|GLUT_DOUBLE|GLUT_RGBA);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(800,800);
    glutCreateWindow("CG-TP@DI-UM");

    GLenum err = glewInit();
    if(GLEW_OK != err){
        printf("ERRO NO GLEW!Mensagem: %s\n", glewGetErrorString(err));
        return 0;
    }

    cena = (parseFile(argv[1]));

    //glm::mat4 matrizInicial = glm::mat4(1.0f);
    //matrizAtual = matrizInicial;

    cout << "Fim parse xml" << endl;
    if((cena) == nullptr){
        printf("Erro no parsing!\n");
        return 1;
    }


// Required callback registry

    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutReshapeFunc(changeSize);

// Callback registration for keyboard processing
    glutKeyboardFunc(processKeys);
    glutSpecialFunc(processSpecialKeys);
    glutMouseFunc(processMouseButtons);
    glutMotionFunc(processMouseMotion);

//  OpenGL settings
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glEnableClientState(GL_VERTEX_ARRAY);

    initGL();

// enter GLUT's main cycle
    glutMainLoop();



    return 1;
}
