#include "LuzPontual.h"

LuzPontual::LuzPontual() : Luz(){}

LuzPontual::LuzPontual(float p[4],float d[4],float amb[4],float e[4],float at) : Luz(p,d,amb,e) {
	atenuacao = at;
}

void LuzPontual::desenhaLuz(){



	// posicao
	glLightfv(GL_LIGHT0, GL_POSITION, this->getPosicao());
	
	// cores
	glLightfv(GL_LIGHT0, GL_AMBIENT, this->getAmbiente());
	glLightfv(GL_LIGHT0, GL_DIFFUSE, this->getDifusa());
	glLightfv(GL_LIGHT0, GL_DIFFUSE, this->getEspecular()); 

	//atenuacao
	glLightf(GL_LIGHT0,GL_LINEAR_ATTENUATION,atenuacao);

}
