#include "Grupo.h"
#include <vector>
#include <iostream>

using namespace std;


Grupo::Grupo(int id) {
	this->id = id;
}


int Grupo::getID(){
	return id;
}

vector<Operacao*> Grupo::getOperacoes(){
	return operacoes;
}


vector<Figura*> Grupo::getFiguras(){
	return figuras;
}

vector<Grupo*> Grupo::getGrupos(){
	return grupos;
}

void Grupo::adicionaOperacao(Operacao* a){
	operacoes.push_back(a);
}

void Grupo::adicionaFigura(Figura* a){
	figuras.push_back(a);
}


void Grupo::adicionaGrupo(Grupo* a){
	grupos.push_back(a);
}

string Grupo::toString(){
	string res="";

	cout << "Grupo id: " << id << endl;

	for(Operacao* op: operacoes){
		op->toString();
	}


	for(Figura* f: figuras){
		f->toString();
	}


	for(Grupo* g: grupos){
		g->toString();
	}

	cout << "Fim grupo id: " << id << endl;

	return res;
}