#ifndef __LuzDirecional_H__
#define __LuzDirecional_H__

#include <GL/glew.h>
#include <math.h>
#include <string>
#include <vector>

#include "Ponto.h"
#include <GL/glut.h>
#include <IL/il.h>

using namespace std;

class LuzDirecional : public Luz {
	
private:
	
public:
	LuzDrecional();
	
	LuzDirecional(float[4],float[4],float[4],float[4]);
    	
	void desenhaLuz();

};
		

#endif
