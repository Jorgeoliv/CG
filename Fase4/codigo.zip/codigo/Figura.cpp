#include "Figura.h"
#include <iostream>

using namespace std;


Figura::Figura() {
}



Figura::Figura(vector<Ponto*> ps,vector<Ponto*> ns,vector<Ponto*> ts, int idt) {
	this->adicionaPontos(ps,ns,ts);
    idTextura = idt;
}


void Figura::adicionaPontos(vector<Ponto*> ps, vector<Ponto*> ns, vector<Ponto*> ts){
	numeroPontos = ps.size();
	float* vertices = (float*) malloc(sizeof(float) * ps.size() * 3);

	numeroNormais = ns.size();
	float* norm = (float*) malloc(sizeof(float) * ns.size() * 3);

	numeroTexturas = ts.size();
	float* text = (float*) malloc(sizeof(float) * ts.size() * 2);

	int i = 0;
	for(Ponto* p: ps){
		vertices[i++] = p->getX();
		vertices[i++] = p->getY();
		vertices[i++] = p->getZ();
	}

	i=0;
	for(Ponto* p: ns){
		norm[i++] = p->getX();
      //  cout << "Normais X: " << norm[i-1] << endl;
		norm[i++] = p->getY();
        //cout << "Normais Y: " << norm[i-1] << endl;
		norm[i++] = p->getZ();
        //cout << "Normais Z: " << norm[i-1] << endl;
	}

	i=0;
	for(Ponto* p: ts){
		text[i++] = p->getX();
        if(text[i-1] < 0) /*norm[i-1]*=-1;*/ cout << "Texs X: " << norm[i-1] << endl;
		text[i++] = p->getY();
        if(text[i-1] < 0) /*norm[i-1]*=-1;*/ cout << "Texs Y: " << norm[i-1] << endl;
	}

    cout << numeroPontos << endl;

	glGenBuffers(1, pontos);
	glBindBuffer(GL_ARRAY_BUFFER, pontos[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * numeroPontos * 3, vertices, GL_STATIC_DRAW);

	glGenBuffers(1, normais);
	glBindBuffer(GL_ARRAY_BUFFER, normais[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * numeroNormais * 3, norm, GL_STATIC_DRAW);

	glGenBuffers(1, texturas);
	glBindBuffer(GL_ARRAY_BUFFER, texturas[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * numeroTexturas * 2, text, GL_STATIC_DRAW);

	free(vertices);
	free(norm);
	free(text);
}

GLuint Figura::getPontos(){
	return pontos[0];
}


void Figura::desenha(){

    cout << "Desenhar" << endl;

    cout << idTextura << endl;

    glBindTexture(GL_TEXTURE_2D, idTextura);

    glBindBuffer(GL_ARRAY_BUFFER, pontos[0]);
	glVertexPointer(3, GL_FLOAT, 0, 0);

	glBindBuffer(GL_ARRAY_BUFFER, normais[0]);
	glNormalPointer(GL_FLOAT,0,0);

	glBindBuffer(GL_ARRAY_BUFFER,texturas[0]);
	glTexCoordPointer(2,GL_FLOAT,0,0);

	//glBindTexture(GL_TEXTURE_2D, 0);


    glDrawArrays(GL_TRIANGLES, 0, numeroPontos);


}


string Figura::toString(){
	string res="";

	/*for(Ponto* p: pontos){
		res+= " { " + p->toString() + " } ";
	}*/
	return res;
}
