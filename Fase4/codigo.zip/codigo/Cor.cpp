include "Cor.h"

Cor::Cor(){
}

Cor::Cor(float r, float g, float b){
	this->r = r;
	this->g = g;
	this->b = b;
}

float Cor::getR(){
	return r;
}

float Cor::getG(){
	return g;
}

float Cor::getB(){
	return b;
}

void Cor::setR(float c){
	r = c;
}

void Cor::setG(float c){
	g = c;
}

void Cor::setB(float c){
	b = c;
}

