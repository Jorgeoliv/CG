#include "Material.h"

Material::Material(){
}

Material::Material(Cor* dif, Cor* amb, Cor* esp, Cor* emi, float shi){
	difusa[3] = -1;
	ambiente[3] = -1;

	if(dif != NULL){
		difusa[0] = dif->getR();
		difusa[1] = dif->getG();
		difusa[2] = dif->getB();
		difusa[3] = 1;
	}

	if(amb != NULL){
		ambiente[0] = amb->getR();
		ambiente[1] = amb->getG();
		ambiente[2] = amb->getB();
		ambiente[3] = 1;
	}

	especular[0] = esp->getR();
	especular[1] = esp->getG();
	especular[2] = esp->getB();
	especular[3] = 1;

	emissiva[0] = emi->getR();
	emissiva[1] = emi->getG();
	emissiva[2] = emi->getB();
	emissiva[3] = 1;

	shininess = shi;
}

void Material::desenha() {
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
	
	if(difusa[3] != -1)
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, difusa);
	if(ambiente[3] != -1)
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, ambiente);
	
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, especular);
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, emissiva);
}
