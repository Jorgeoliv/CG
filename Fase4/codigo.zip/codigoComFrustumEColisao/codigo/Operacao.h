#ifndef __OPERACAO_H__
#define __OPERACAO_H__

#include <math.h>
#include <string>
#include <vector>
#include "Ponto.h"
#include "glm/glm.hpp"
#include "glm/gtx/transform.hpp"


using namespace std;

class Operacao {


    float x;
    float y;
    float z;

    //podiamos ter um inteiro a dizer o tipo ou ter aquela cena do ENUM

public:
	Operacao();
	Operacao(float,float,float);

    float getX();
    float getY();
    float getZ();
    
    void setX(float);
	void setY(float);
	void setZ(float);

	virtual void aplicaOperacao(glm::mat4*) = 0;

    virtual string toString() = 0;
};
		

#endif
